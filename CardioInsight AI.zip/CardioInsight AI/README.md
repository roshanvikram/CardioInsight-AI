# Exploratory Data Analysis and Visualization of Heart Disease Using Statistical Analysis and Deep Learning

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![TensorFlow 2.x](https://img.shields.io/badge/TensorFlow-2.x-orange.svg)](https://www.tensorflow.org/)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.x-yellow.svg)](https://scikit-learn.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Academic Assessment](https://img.shields.io/badge/Evaluation-B.Tech%20AI%26DS%20(40%20Marks)-purple.svg)](#)

---

### 🎓 Academic Accreditation
- **Student Name:** ROSHAN VIKRAM A V
- **Roll Number:** 25ADL09
- **Department:** Department of Artificial Intelligence and Data Science
- **Institution:** KPR Institute of Engineering and Technology
- **Submission Date:** 15.10.2026 (15th October 2026)
- **Course / Assessment:** B.Tech AI & DS Capstone Project (40 Marks Evaluation)

---

## 📌 Executive Summary
According to the World Health Organization (WHO), Cardiovascular Diseases (CVDs) account for 17.9 million deaths annually. This repository delivers an academic data science and deep learning capstone project designed for **B.Tech Artificial Intelligence and Data Science** students.

The project examines coronary artery disease using the landmark **UCI Heart Disease Dataset**. It demonstrates an end-to-end data science lifecycle: from data auditing and evidence-based clinical feature derivation (expanding the feature space to **17 fields**), through the **Seven Stages of Visualization**, inferential statistical hypothesis testing, and deep Multilayer Perceptron (MLP) classification in TensorFlow/Keras, to rigorous benchmarking against linear and ensemble baselines on an isolated, leak-free test cohort.

---

## 🗂️ Project Repository Architecture

```text
heart-disease-eda-deep-learning/
│
├── README.md                                # Comprehensive project documentation
├── requirements.txt                         # Pinned production dependencies
├── .gitignore                               # Standard exclusion rules
├── build_notebook.py                        # Jupyter notebook builder
├── generate_reports.py                      # Academic Word & PDF report builder
│
├── data/
│   ├── heart.csv                            # Ingested dataset (1,025 instances)
│   └── README.md                            # Dataset provenance & clinical dictionary
│
├── notebooks/
│   └── Heart_Disease_EDA_Deep_Learning.ipynb# Complete self-contained notebook
│
├── src/
│   ├── data_preprocessing.py                # Ingestion, feature engineering, split
│   ├── eda.py                               # Statistical testing & EDA visualization
│   ├── train_model.py                       # MLP model & hyperparameter tuning
│   └── evaluate_model.py                    # Test metrics, benchmarking & interpretability
│
├── reports/
│   ├── Project_Report.docx                  # Editable academic report (Word format)
│   └── Project_Report.pdf                   # Publication-formatted academic PDF
│
├── results/                                 # 15 High-resolution (300 DPI) generated figures
│   ├── 01_target_distribution.png
│   ├── 02_age_distribution.png
│   ├── 03_correlation_heatmap.png
│   ├── 04_thalach_boxplot.png
│   ├── 05_age_vs_thalach_scatter.png
│   ├── 06_pairplot_selected_features.png
│   ├── 07_chest_pain_analysis.png
│   ├── 08_st_depression_slope_analysis.png
│   ├── eval_training_validation_loss.png
│   ├── eval_training_validation_accuracy.png
│   ├── eval_confusion_matrix.png
│   ├── eval_roc_curve.png
│   ├── eval_precision_recall_curve.png
│   ├── eval_feature_importance.png
│   └── eval_model_comparison.png
│
└── models/
    └── best_heart_disease_mlp.keras         # Serialized best trained Keras model
```

---

## 🩺 Dataset & Clinical Feature Engineering (17 Fields)
The dataset originates from the **UCI Machine Learning Repository** (Cleveland Foundation). The raw archive contains 1,025 records.

### Preventing Data Leakage
An audit revealed that the 1,025 records contain 723 bootstrap duplicate rows of an original 302-patient cohort. To prevent **data leakage** (where duplicate patients in test artificially inflate performance), we perform deduplication down to 302 unique patients before splitting:
- **Training Cohort:** 211 patients (69.9%)
- **Validation Cohort:** 45 patients (14.9%)
- **Held-Out Testing Cohort:** 46 patients (15.2%)

### Evidence-Based Feature Expansion
To fulfill the requirement of **at least 15 fields** without fabricating synthetic observations, three validated cardiovascular indices were mathematically derived conforming to American Heart Association (AHA) and NCEP ATP III cardiology consensus guidelines:
1. `max_hr_pct`: Percentage of age-predicted maximum heart rate using the Fox/Tanaka formula: $\frac{\text{thalach}}{220 - \text{age}} \times 100$.
2. `bp_category`: AHA Blood Pressure Classification (0: Normal, 1: Elevated, 2: Stage 1 HTN, 3: Stage 2 HTN).
3. `chol_category`: NCEP ATP III Cholesterol Risk Category (0: Desirable, 1: Borderline High, 2: High).

Together with the 14 raw clinical features (`age`, `sex`, `cp`, `trestbps`, `chol`, `fbs`, `restecg`, `thalach`, `exang`, `oldpeak`, `slope`, `ca`, `thal`, `target`), the final analytical space comprises **17 structured fields**.

---

## 🎨 The Seven Stages of Visualization Framework
We explicitly map Ben Fry's and Colin Ware's Seven Stages of Visualization workflow:
1. **Acquire:** Ingestion of genuine patient records from verified local storage.
2. **Parse:** Schema identification, typing, and zero-missingness confirmation.
3. **Filter:** Deduplication of 723 rows; IQR-based outlier threshold calculations.
4. **Mine:** Extraction of descriptive statistics, t-tests, Chi-square tests, and feature derivations.
5. **Represent:** Selection of boxplots with strip jitter, correlation heatmaps, violin plots, and ROC curves.
6. **Refine:** Professional aesthetics (`#2B5C8F` and `#D9534F` palettes), crisp labels, and 300 DPI rendering.
7. **Interact & Communicate:** Synthesis of clinical interpretations and diagnostic limitations.

---

## 📊 Exploratory Data Analysis (EDA) Highlights

### Inferential Hypothesis Testing Results
- **Maximum Heart Rate (`thalach`):** $t = -14.862, p = 3.42 \times 10^{-45}$ (Statistically Significant)
- **ST Depression (`oldpeak`):** $t = 15.409, p = 3.87 \times 10^{-47}$ (Statistically Significant)
- **Patient Age (`age`):** $t = 7.574, p = 8.18 \times 10^{-14}$ (Statistically Significant)
- **Chest Pain Type (`cp`):** $\chi^2 = 280.98, p = 1.30 \times 10^{-60}$ (Statistically Significant)
- **Thalassemia (`thal`):** $\chi^2 = 280.33, p = 1.80 \times 10^{-60}$ (Statistically Significant)
- **Fasting Blood Sugar (`fbs`):** $\chi^2 = 1.513, p = 0.2186$ (Not statistically significant at $\alpha = 0.05$).

### Visualization Gallery

| Figure 1: Target Class Distribution | Figure 2: Age Distribution Stratified |
| :---: | :---: |
| ![Target Distribution](results/01_target_distribution.png) | ![Age Distribution](results/02_age_distribution.png) |

| Figure 3: Correlation Heatmap | Figure 4: Maximum Heart Rate Boxplot |
| :---: | :---: |
| ![Correlation Heatmap](results/03_correlation_heatmap.png) | ![Thalach Boxplot](results/04_thalach_boxplot.png) |

| Figure 5: Age vs Max Heart Rate | Figure 6: Key Medical Features Pairplot |
| :---: | :---: |
| ![Scatterplot](results/05_age_vs_thalach_scatter.png) | ![Pairplot](results/06_pairplot_selected_features.png) |

---

## 🧠 Deep Learning Architecture & Hyperparameter Tuning

### Network Topology
```text
Input (16 features)
   │
   ▼
Dense (64 units, ReLU, He Normal, L2 Regularization=0.001)
   │
   ▼
Batch Normalization Layer
   │
   ▼
Dropout Layer (Rate = 0.20)
   │
   ▼
Dense (32 units, ReLU, L2 Regularization=0.001)
   │
   ▼
Dropout Layer (Rate = 0.10)
   │
   ▼
Dense (16 units, ReLU)
   │
   ▼
Dense (1 unit, Sigmoid Activation) -> P(Heart Disease)
```

### Hyperparameter Search on Validation Cohort (15%)
| Experiment | Hidden Layers | Learning Rate | Dropout | Batch Size | Val Loss | Val AUC | Selection Status |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Exp 1: Baseline MLP** | (64, 32, 16) | 0.0010 | 0.20 | 16 | 0.5521 | 0.9008 | Baseline |
| **Exp 2: Wider Capacity** | (128, 64, 32) | 0.0010 | 0.30 | 16 | 0.7895 | 0.9038 | Overfitting risk |
| **Exp 3: Reduced LR** | (64, 32, 16) | 0.0003 | 0.20 | 16 | 0.5614 | 0.9048 | Slow convergence |
| **Exp 4: Larger Batch** | **(64, 32, 16)** | **0.0010** | **0.20** | **32** | **0.5009** | **0.9276** | **Optimal Selected** |
| **Exp 5: Light Reg.** | (64, 32, 16) | 0.0010 | 0.10 | 16 | 0.5852 | 0.8889 | High variance |

---

## 📈 Model Evaluation & Baseline Comparison

### Test Set Metrics (Held-Out 46-Patient Cohort)
Evaluated on the completely unseen 15% testing split:

| Model Architecture | Test Accuracy | Precision (PPV) | Recall (Sensitivity) | Specificity | F1-Score | ROC-AUC |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **MLP Neural Network (Keras)** | **71.74%** | **83.33%** | **60.00%** | **85.71%** | **0.6977** | **0.8210** |
| **Logistic Regression** | 73.91% | 84.21% | 64.00% | 85.71% | 0.7273 | 0.8438 |
| **Random Forest** | 73.91% | 84.21% | 64.00% | 85.71% | 0.7273 | 0.8305 |

| Figure 7: Confusion Matrix (MLP) | Figure 8: ROC Curves Comparison |
| :---: | :---: |
| ![Confusion Matrix](results/eval_confusion_matrix.png) | ![ROC Curve](results/eval_roc_curve.png) |

| Figure 9: Training Loss Curve | Figure 10: Model Comparison Benchmark |
| :---: | :---: |
| ![Training Loss](results/eval_training_validation_loss.png) | ![Model Comparison](results/eval_model_comparison.png) |

### Permutation Feature Importance
![Permutation Feature Importance](results/eval_feature_importance.png)
- **Leading Predictors:** Peak exercise ST segment slope (`slope`), thallium heart scan defect (`thal`), and major vessels colored by fluoroscopy (`ca`).
- **Academic Insight:** On small tabular clinical cohorts ($N \approx 300$), shallow linear models and random forests often match deep networks due to lower parametric variance.

---

## 🚀 Step-by-Step Installation & Execution Guide

### Prerequisites
- Python 3.10, 3.11, 3.12, or 3.13 installed.
- Git installed.

### 1. Clone or Open Workspace
```bash
git clone https://github.com/<your-username>/heart-disease-eda-deep-learning.git
cd heart-disease-eda-deep-learning
```

### 2. Install Required Dependencies
```bash
pip install -r requirements.txt
```

### 3. Run Pipeline Scripts Sequentially
```bash
# Step A: Data Preprocessing & Leakage-Free Splitting
python src/data_preprocessing.py

# Step B: Exploratory Data Analysis & Statistical Testing (generates EDA figures)
python src/eda.py

# Step C: Model Training & Hyperparameter Tuning (trains best MLP model)
python src/train_model.py

# Step D: Test Evaluation, Baseline Benchmarking & Feature Importance
python src/evaluate_model.py

# Step E: Generate Word (DOCX) and PDF Academic Reports
python generate_reports.py
```

### 4. Interactive Jupyter Notebook
Launch Jupyter Lab or Notebook:
```bash
jupyter notebook notebooks/Heart_Disease_EDA_Deep_Learning.ipynb
```
The notebook is also 100% compatible with **Google Colab** (simply upload `notebooks/Heart_Disease_EDA_Deep_Learning.ipynb` and `data/heart.csv`).

---

## 📤 Step-by-Step Instructions to Upload to Your Personal GitHub

To publish this project under your own GitHub account:

1. **Log in to GitHub** and create a new repository:
   - Repository Name: `heart-disease-eda-deep-learning`
   - Description: *Exploratory Data Analysis and Visualization of Heart Disease Using Statistical Analysis and Deep Learning*
   - Set visibility to **Public**.
   - Do **NOT** initialize with a README, .gitignore, or license (these already exist in the project).

2. **Initialize Git locally** in the project directory:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Complete Heart Disease EDA and Deep Learning Capstone Project"
   ```

3. **Link to your remote GitHub repository & push**:
   ```bash
   git branch -M main
   git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/heart-disease-eda-deep-learning.git
   git push -u origin main
   ```

---

## 📑 Complete Academic Reports
Pre-generated, publication-ready academic reports containing all tables, statistics, figure captions, and citations are located in `reports/`:
- **Word Document:** [`reports/Project_Report.docx`](reports/Project_Report.docx) *(Fully editable)*
- **PDF Document:** [`reports/Project_Report.pdf`](reports/Project_Report.pdf) *(Formatted academic publication)*

---

## ⚠️ Educational Use & Medical Disclaimer
**THIS PROJECT IS DEVELOPED SOLELY FOR ACADEMIC AND EDUCATIONAL PURPOSES WITHIN THE B.TECH ARTIFICIAL INTELLIGENCE AND DATA SCIENCE CURRICULUM.**
The predictions, statistical analyses, and models provided in this repository do NOT constitute clinical diagnoses, medical advice, or therapeutic guidance. Clinical decision-making must always be performed by licensed medical physicians using certified diagnostic equipment.

---

## 📚 Academic References (IEEE Style)
1. R. Detrano et al., "International application of a new probability algorithm for the diagnosis of coronary artery disease," *Am. J. Cardiol.*, vol. 64, no. 5, pp. 304–310, 1989.
2. H. Tanaka, K. D. Monahan, and D. R. Seals, "Age-predicted maximal heart rate revisited," *J. Am. Coll. Cardiol.*, vol. 37, no. 1, pp. 153–156, 2001.
3. Y. LeCun, Y. Bengio, and G. Hinton, "Deep learning," *Nature*, vol. 521, no. 7553, pp. 436–444, 2015.
4. M. Fernández-Delgado et al., "Do we need hundreds of classifiers to solve real world classification problems?" *J. Mach. Learn. Res.*, vol. 15, no. 1, pp. 3133–3181, 2014.
5. B. Shneiderman, "The eyes have it: A task by data type taxonomy for information visualizations," in *IEEE Symposium on Visual Languages*, 1996, pp. 336–343.
6. World Health Organization, "Cardiovascular diseases (CVDs) key facts," *WHO Fact Sheets*, Geneva, Switzerland, 2023.
