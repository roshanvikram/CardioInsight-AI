"""
Script to generate the complete, self-contained, Google Colab and local Jupyter-compatible
notebook: notebooks/Heart_Disease_EDA_Deep_Learning.ipynb
"""

import nbformat as nbf
import os

nb = nbf.v4.new_notebook()
nb.metadata = {
    "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
    },
    "language_info": {
        "name": "python",
        "version": "3.13.0"
    }
}

cells = []

# Title & Metadata
cells.append(nbf.v4.new_markdown_cell("""# Exploratory Data Analysis and Visualization of Heart Disease Using Statistical Analysis and Deep Learning
**Course:** B.Tech Artificial Intelligence and Data Science  
**Student Name:** ROSHAN VIKRAM A V  
**Roll Number:** 25ADL09  
**Department:** Department of Artificial Intelligence and Data Science  
**Institution:** KPR Institute of Engineering and Technology  
**Submission Date:** 15.10.2026 (15th October 2026)  
**Evaluation Standard:** Academic Capstone Project (40 Marks Evaluation)  
**Target Environment:** Local Python / Jupyter Lab / Google Colab Compatible  

---

### Abstract
This project presents an end-to-end data science and deep learning study exploring cardiovascular disease using the landmark UCI Heart Disease dataset. We establish a rigorous 7-stage visualization pipeline and conduct univariate, bivariate, multivariate, and distribution-based statistical analysis. Clinical feature engineering is introduced based on AHA and NCEP ATP III guidelines (expanding the feature space to 17 structured fields without synthetic fabrication). A deep Multilayer Perceptron (MLP) classification network is constructed in TensorFlow/Keras, systematically tuned across 5 architectural configurations, and evaluated against Logistic Regression and Random Forest baselines on an isolated held-out test cohort (15%). Permutation importance analysis identifies peak exercise ST slope, thalassemia defect type, and major fluoroscopy vessels as prime predictive drivers.
"""))

# Section 1: Setup & Imports
cells.append(nbf.v4.new_markdown_cell("""## 1. Environment Setup & Library Imports
Importing foundational scientific computing, data manipulation, statistical testing, visualization, and deep learning libraries.
"""))

cells.append(nbf.v4.new_code_cell("""import os
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

import tensorflow as tf
from tensorflow.keras import layers, models, regularizers, callbacks
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, roc_curve, precision_recall_curve,
    classification_report, average_precision_score
)

# Display helper for tabular inspection
try:
    from IPython.display import display
except Exception:
    def display(*args):
        for a in args:
            print(a)

# Plotting aesthetics configuration
plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
plt.rcParams['figure.dpi'] = 150
plt.rcParams['font.sans-serif'] = 'Arial'
plt.rcParams['axes.titlesize'] = 13
plt.rcParams['axes.labelsize'] = 11

# Set reproducible seeds
SEED = 42
os.environ['PYTHONHASHSEED'] = str(SEED)
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

print(f"TensorFlow Version: {tf.__version__}")
print(f"Pandas Version: {pd.__version__}")
"""))

# Section 2: Data Ingestion & Understanding
cells.append(nbf.v4.new_markdown_cell("""## 2. Dataset Ingestion & Data Understanding
We ingest the dataset from `data/heart.csv` (or fallback `archive/heart.csv`). We inspect the dimensions, column types, missingness, duplicate instances, and target class distributions.
"""))

cells.append(nbf.v4.new_code_cell("""# Locate and load the dataset
data_path = 'data/heart.csv' if os.path.exists('data/heart.csv') else '../data/heart.csv'
if not os.path.exists(data_path):
    data_path = 'archive/heart.csv' if os.path.exists('archive/heart.csv') else '../archive/heart.csv'

df_raw = pd.read_csv(data_path)
print(f"Dataset Successfully Loaded. Dimensions: {df_raw.shape[0]} rows x {df_raw.shape[1]} columns")
print(f"Missing Values Across All Columns: {df_raw.isnull().sum().sum()}")
print(f"Duplicate Rows Detected: {df_raw.duplicated().sum()}")

# Display First 5 and Last 5 Records
display(df_raw.head())
display(df_raw.tail())
"""))

cells.append(nbf.v4.new_code_cell("""# Summary Information & Data Types
df_raw.info()
"""))

# Section 3: Clinical Feature Engineering
cells.append(nbf.v4.new_markdown_cell("""## 3. Evidence-Based Clinical Feature Engineering
To fulfill the requirement of **at least 15 fields** without fabricating synthetic observations, we engineer clinically validated cardiovascular parameters derived from established medical literature:
1. `max_hr_pct`: Percentage of age-predicted maximum heart rate using the Fox/Tanaka formula: $\\frac{\\text{thalach}}{220 - \\text{age}} \\times 100$.
2. `bp_category`: American Heart Association (AHA) Blood Pressure Staging (0: Normal, 1: Elevated, 2: Stage 1 HTN, 3: Stage 2 HTN).
3. `chol_category`: National Cholesterol Education Program (NCEP ATP III) Risk Classification (0: Desirable, 1: Borderline High, 2: High).

This expands our analytical space to **17 structured fields**.
"""))

cells.append(nbf.v4.new_code_cell("""def engineer_features(df):
    df_feat = df.copy()
    # 1. Age-Predicted Maximum Heart Rate Percentage
    df_feat['max_hr_pct'] = (df_feat['thalach'] / (220 - df_feat['age']) * 100).round(2)
    
    # 2. AHA Blood Pressure Categories
    def classify_bp(bp):
        if bp < 120: return 0
        elif 120 <= bp < 130: return 1
        elif 130 <= bp < 140: return 2
        else: return 3
    df_feat['bp_category'] = df_feat['trestbps'].apply(classify_bp)
    
    # 3. NCEP ATP III Cholesterol Categories
    def classify_chol(c):
        if c < 200: return 0
        elif 200 <= c < 240: return 1
        else: return 2
    df_feat['chol_category'] = df_feat['chol'].apply(classify_chol)
    
    return df_feat

df_engineered = engineer_features(df_raw)
print(f"Features after clinical derivation: {df_engineered.shape[1]} fields")
display(df_engineered.head(3))
"""))

# Section 4: IQR Outlier Analysis
cells.append(nbf.v4.new_markdown_cell("""## 4. Outlier Detection (Interquartile Range Rule)
We examine extreme clinical observations using the Interquartile Range method ($IQR = Q_3 - Q_1$). Outliers are clinically justified and retained rather than blindly eliminated to preserve pathological variability.
"""))

cells.append(nbf.v4.new_code_cell("""num_cols = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak', 'max_hr_pct']
outlier_summary = []

for col in num_cols:
    q1 = df_engineered[col].quantile(0.25)
    q3 = df_engineered[col].quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    outliers = df_engineered[(df_engineered[col] < lower_bound) | (df_engineered[col] > upper_bound)]
    outlier_summary.append({
        "Feature": col,
        "Q1": round(q1, 2),
        "Q3": round(q3, 2),
        "IQR": round(iqr, 2),
        "Lower Bound": round(lower_bound, 2),
        "Upper Bound": round(upper_bound, 2),
        "Outlier Count": len(outliers),
        "Outlier %": round((len(outliers) / len(df_engineered)) * 100, 2)
    })

df_outliers = pd.DataFrame(outlier_summary)
display(df_outliers)
"""))

# Section 5: Deduplication & Split
cells.append(nbf.v4.new_markdown_cell("""## 5. Deduplication & Leak-Free Train-Validation-Test Splitting
The 1,025 raw records represent repeated instances of 302 unique patients. We perform deduplication to prevent **data leakage** across splits. The cohort is partitioned into:
- **70% Training Cohort** (211 patients)
- **15% Validation Cohort** (45 patients)
- **15% Held-Out Testing Cohort** (46 patients)
Standardization (`StandardScaler`) is fitted strictly on the Training Cohort.
"""))

cells.append(nbf.v4.new_code_cell("""# Deduplicate cohort
df_clean = df_engineered.drop_duplicates().reset_index(drop=True)
print(f"Cohort deduplicated: {len(df_engineered)} -> {len(df_clean)} unique patients.")

X = df_clean.drop(columns=['target'])
y = df_clean['target'].values
feature_names = list(X.columns)

# Stratified Splitting: 70% Train, 15% Val, 15% Test
X_train_raw, X_temp_raw, y_train, y_temp = train_test_split(
    X, y, test_size=0.30, random_state=SEED, stratify=y
)
X_val_raw, X_test_raw, y_val, y_test = train_test_split(
    X_temp_raw, y_temp, test_size=0.50, random_state=SEED, stratify=y_temp
)

# Fit scaler solely on training data
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train_raw)
X_val = scaler.transform(X_val_raw)
X_test = scaler.transform(X_test_raw)

print(f"Training instances: {X_train.shape[0]} ({round(X_train.shape[0]/len(df_clean)*100, 1)}%)")
print(f"Validation instances: {X_val.shape[0]} ({round(X_val.shape[0]/len(df_clean)*100, 1)}%)")
print(f"Testing instances: {X_test.shape[0]} ({round(X_test.shape[0]/len(df_clean)*100, 1)}%)")
"""))

# Section 6: Statistical Analysis (Univariate, Bivariate, Multivariate)
cells.append(nbf.v4.new_markdown_cell("""## 6. Comprehensive Statistical Analysis
### A. Univariate Statistics
Evaluation of central tendency, dispersion, quartiles, and skewness for all numerical features.
"""))

cells.append(nbf.v4.new_code_cell("""univ_rows = []
for col in num_cols:
    s = df_clean[col]
    univ_rows.append({
        "Feature": col,
        "Mean": round(s.mean(), 2),
        "Median": round(s.median(), 2),
        "Std Dev": round(s.std(), 2),
        "Variance": round(s.var(), 2),
        "Min": round(s.min(), 2),
        "Q1": round(s.quantile(0.25), 2),
        "Q3": round(s.quantile(0.75), 2),
        "IQR": round(s.quantile(0.75) - s.quantile(0.25), 2),
        "Max": round(s.max(), 2),
        "Skewness": round(s.skew(), 3)
    })
df_univ = pd.DataFrame(univ_rows)
display(df_univ)
"""))

cells.append(nbf.v4.new_markdown_cell("""### B. Bivariate Hypothesis Testing
- **Continuous Variables:** Two-sample independent t-test & Mann-Whitney U test across disease status.
- **Categorical Variables:** Pearson's Chi-Square Test of Independence with target.
"""))

cells.append(nbf.v4.new_code_cell("""# Hypothesis Testing on Continuous Features
g0 = df_clean[df_clean['target'] == 0]
g1 = df_clean[df_clean['target'] == 1]
t_tests = []

for col in num_cols:
    v0 = g0[col]
    v1 = g1[col]
    t_stat, p_val = stats.ttest_ind(v0, v1, equal_var=False)
    u_stat, u_pval = stats.mannwhitneyu(v0, v1, alternative='two-sided')
    t_tests.append({
        "Feature": col,
        "Mean (Normal)": round(v0.mean(), 2),
        "Mean (Disease)": round(v1.mean(), 2),
        "t-statistic": round(t_stat, 3),
        "p-value (t-test)": f"{p_val:.4e}",
        "p-value (Mann-Whitney)": f"{u_pval:.4e}",
        "Significant (p<0.05)": "Yes" if p_val < 0.05 else "No"
    })
display(pd.DataFrame(t_tests))
"""))

cells.append(nbf.v4.new_code_cell("""# Chi-Square Tests on Categorical Features
cat_cols = ['sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'ca', 'thal', 'bp_category', 'chol_category']
chi_tests = []

for col in cat_cols:
    ct = pd.crosstab(df_clean[col], df_clean['target'])
    chi2, p_val, dof, _ = stats.chi2_contingency(ct)
    chi_tests.append({
        "Feature": col,
        "Chi2 Stat": round(chi2, 3),
        "Degrees of Freedom": dof,
        "p-value": f"{p_val:.4e}",
        "Significant (p<0.05)": "Yes" if p_val < 0.05 else "No"
    })
display(pd.DataFrame(chi_tests))
"""))

# Section 7: EDA Visualizations
cells.append(nbf.v4.new_markdown_cell("""## 7. Exploratory Data Visualizations
Below are the core exploratory visualizations adhering to the **Seven Stages of Visualization** (Acquire, Parse, Filter, Mine, Represent, Refine, Interact).
"""))

cells.append(nbf.v4.new_code_cell("""# Plot 1: Target Distribution
plt.figure(figsize=(7, 4.5))
ax = sns.countplot(data=df_clean, x='target', palette=["#2b5c8f", "#d9534f"], hue='target', legend=False)
plt.title("Target Class Distribution (Heart Disease Prevalence)", fontsize=13, weight='bold')
plt.xlabel("Heart Disease Status (0 = Absent, 1 = Present)")
plt.ylabel("Patient Count")
plt.xticks([0, 1], ["Absence (<50% stenosis)", "Presence (>50% stenosis)"])
for p in ax.patches:
    h = p.get_height()
    pct = (h / len(df_clean)) * 100
    ax.annotate(f"{int(h)} ({pct:.1f}%)", (p.get_x() + p.get_width() / 2., h / 2),
                ha='center', va='center', color='white', weight='bold')
plt.show()
"""))

cells.append(nbf.v4.new_code_cell("""# Plot 2: Age Distribution Stratified by Disease
plt.figure(figsize=(8, 4.5))
sns.histplot(data=df_clean, x='age', hue='target', kde=True, bins=20,
             palette=["#2b5c8f", "#d9534f"], element="step", alpha=0.4)
plt.title("Age Distribution Stratified by Heart Disease Status", fontsize=13, weight='bold')
plt.xlabel("Age (Years)")
plt.ylabel("Patient Frequency")
plt.show()
"""))

cells.append(nbf.v4.new_code_cell("""# Plot 3: Correlation Matrix Heatmap
plt.figure(figsize=(10, 8))
corr_subset = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak', 'max_hr_pct', 'target']
corr_mat = df_clean[corr_subset].corr()
mask = np.triu(np.ones_like(corr_mat, dtype=bool))
cmap = sns.diverging_palette(230, 20, as_cmap=True)
sns.heatmap(corr_mat, mask=mask, cmap=cmap, vmin=-1.0, vmax=1.0, annot=True, fmt=".2f", square=True)
plt.title("Correlation Heatmap of Key Cardiac Metrics", fontsize=13, weight='bold')
plt.show()
"""))

cells.append(nbf.v4.new_code_cell("""# Plot 4: Boxplot of Maximum Heart Rate Across Classes
plt.figure(figsize=(7, 5))
sns.boxplot(data=df_clean, x='target', y='thalach', palette=["#4a90e2", "#e74c3c"], width=0.45, hue='target', legend=False)
sns.stripplot(data=df_clean, x='target', y='thalach', color='black', alpha=0.3, jitter=0.2, size=5)
plt.title("Maximum Heart Rate Achieved (thalach) by Target Class", fontsize=13, weight='bold')
plt.xlabel("Disease Status")
plt.ylabel("Maximum Heart Rate (bpm)")
plt.xticks([0, 1], ["Absence (0)", "Presence (1)"])
plt.show()
"""))

cells.append(nbf.v4.new_code_cell("""# Plot 5: Scatterplot of Age vs Maximum Heart Rate with Regression Trends
plt.figure(figsize=(8, 5))
sns.scatterplot(data=df_clean, x='age', y='thalach', hue='target', palette={0: "#2b5c8f", 1: "#d9534f"}, alpha=0.7, s=50)
sns.regplot(data=df_clean[df_clean['target'] == 0], x='age', y='thalach', scatter=False, color='#2b5c8f', label='Trend: Absence')
sns.regplot(data=df_clean[df_clean['target'] == 1], x='age', y='thalach', scatter=False, color='#d9534f', label='Trend: Presence')
plt.title("Age vs. Maximum Heart Rate Stratified with Linear Fits", fontsize=13, weight='bold')
plt.xlabel("Age (Years)")
plt.ylabel("Max Heart Rate (bpm)")
plt.legend()
plt.show()
"""))

# Section 8: Deep Learning MLP Model
cells.append(nbf.v4.new_markdown_cell("""## 8. Deep Learning Model Construction & Hyperparameter Tuning
We build a Multilayer Perceptron (MLP) architecture in TensorFlow/Keras featuring:
- Input Layer: 16 features
- Dense Layer 1: 64 neurons (ReLU, L2 Regularization, BatchNormalization, Dropout 0.2)
- Dense Layer 2: 32 neurons (ReLU, Dropout 0.1)
- Dense Layer 3: 16 neurons (ReLU)
- Output Layer: 1 neuron (Sigmoid activation for binary classification)
- Optimizer: Adam
- Loss: Binary Cross-Entropy
"""))

cells.append(nbf.v4.new_code_cell("""def build_mlp(input_dim, hidden_units=(64, 32, 16), dropout_rate=0.2, lr=0.001):
    model = models.Sequential([
        layers.Input(shape=(input_dim,)),
        layers.Dense(hidden_units[0], activation='relu', kernel_regularizer=regularizers.l2(0.001)),
        layers.BatchNormalization(),
        layers.Dropout(dropout_rate),
        layers.Dense(hidden_units[1], activation='relu', kernel_regularizer=regularizers.l2(0.001)),
        layers.Dropout(dropout_rate / 2),
        layers.Dense(hidden_units[2], activation='relu'),
        layers.Dense(1, activation='sigmoid')
    ])
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
        loss='binary_crossentropy',
        metrics=['accuracy', tf.keras.metrics.AUC(name='auc'), tf.keras.metrics.Precision(name='precision'), tf.keras.metrics.Recall(name='recall')]
    )
    return model

input_dim = X_train.shape[1]
sample_mlp = build_mlp(input_dim)
sample_mlp.summary()
"""))

cells.append(nbf.v4.new_markdown_cell("""### Hyperparameter Validation Experiments
Comparing 5 configurations strictly on the Validation Set:
"""))

cells.append(nbf.v4.new_code_cell("""tuning_configs = [
    {"name": "Exp 1: Baseline MLP", "units": (64, 32, 16), "lr": 0.001, "drop": 0.2, "batch": 16},
    {"name": "Exp 2: Wider Capacity", "units": (128, 64, 32), "lr": 0.001, "drop": 0.3, "batch": 16},
    {"name": "Exp 3: Reduced LR", "units": (64, 32, 16), "lr": 0.0003, "drop": 0.2, "batch": 16},
    {"name": "Exp 4: Larger Batch", "units": (64, 32, 16), "lr": 0.001, "drop": 0.2, "batch": 32},
    {"name": "Exp 5: Light Regularization", "units": (64, 32, 16), "lr": 0.001, "drop": 0.1, "batch": 16},
]

experiment_results = []
for cfg in tuning_configs:
    m = build_mlp(input_dim, hidden_units=cfg['units'], dropout_rate=cfg['drop'], lr=cfg['lr'])
    es = callbacks.EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
    m.fit(X_train, y_train, validation_data=(X_val, y_val), epochs=35, batch_size=cfg['batch'], verbose=0, callbacks=[es])
    val_loss, val_acc, val_auc, val_prec, val_rec = m.evaluate(X_val, y_val, verbose=0)
    experiment_results.append({
        "Experiment": cfg['name'],
        "Val Loss": round(float(val_loss), 4),
        "Val Accuracy (%)": round(float(val_acc) * 100, 2),
        "Val AUC": round(float(val_auc), 4),
        "Val Recall (%)": round(float(val_rec) * 100, 2)
    })

df_exp = pd.DataFrame(experiment_results)
display(df_exp)
"""))

# Section 9: Final Training & Evaluation
cells.append(nbf.v4.new_markdown_cell("""## 9. Final Training & Evaluation on Held-Out Test Set
We train the selected configuration (Exp 4) with EarlyStopping and ReduceLROnPlateau.
"""))

cells.append(nbf.v4.new_code_cell("""final_model = build_mlp(input_dim, hidden_units=(64, 32, 16), dropout_rate=0.2, lr=0.001)

cb_list = [
    callbacks.EarlyStopping(monitor='val_loss', patience=12, restore_best_weights=True),
    callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=5, min_lr=1e-5)
]

history = final_model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=50,
    batch_size=32,
    callbacks=cb_list,
    verbose=1
)
"""))

cells.append(nbf.v4.new_code_cell("""# Final Evaluation on Held-Out Test Set
y_prob_mlp = final_model.predict(X_test, verbose=0).ravel()
y_pred_mlp = (y_prob_mlp >= 0.5).astype(int)

cm = confusion_matrix(y_test, y_pred_mlp)
acc = accuracy_score(y_test, y_pred_mlp)
prec = precision_score(y_test, y_pred_mlp)
rec = recall_score(y_test, y_pred_mlp)
f1 = f1_score(y_test, y_pred_mlp)
auc = roc_auc_score(y_test, y_prob_mlp)

print(f"--- TEST SET EVALUATION METRICS ---")
print(f"Accuracy:  {acc:.4f} ({acc*100:.2f}%)")
print(f"Precision: {prec:.4f} ({prec*100:.2f}%)")
print(f"Recall:    {rec:.4f} ({rec*100:.2f}%)")
print(f"F1-Score:  {f1:.4f}")
print(f"ROC-AUC:   {auc:.4f}")

plt.figure(figsize=(5, 4.5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=["Normal", "Disease"], yticklabels=["Normal", "Disease"])
plt.title("Confusion Matrix - Test Set")
plt.xlabel("Predicted")
plt.ylabel("True")
plt.show()
"""))

# Section 10: Baseline Comparison & Feature Importance
cells.append(nbf.v4.new_markdown_cell("""## 10. Baseline Model Comparison & Permutation Feature Importance
We benchmark the MLP against Logistic Regression and Random Forest on the identical test cohort.
"""))

cells.append(nbf.v4.new_code_cell("""# Baseline Models
lr = LogisticRegression(random_state=SEED).fit(X_train, y_train)
rf = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=SEED).fit(X_train, y_train)

lr_prob = lr.predict_proba(X_test)[:, 1]
rf_prob = rf.predict_proba(X_test)[:, 1]

models_bench = [
    {"Model": "MLP (Keras)", "Accuracy": acc, "Precision": prec, "Recall": rec, "F1-Score": f1, "ROC-AUC": auc},
    {"Model": "Logistic Regression", "Accuracy": accuracy_score(y_test, lr.predict(X_test)),
     "Precision": precision_score(y_test, lr.predict(X_test)), "Recall": recall_score(y_test, lr.predict(X_test)),
     "F1-Score": f1_score(y_test, lr.predict(X_test)), "ROC-AUC": roc_auc_score(y_test, lr_prob)},
    {"Model": "Random Forest", "Accuracy": accuracy_score(y_test, rf.predict(X_test)),
     "Precision": precision_score(y_test, rf.predict(X_test)), "Recall": recall_score(y_test, rf.predict(X_test)),
     "F1-Score": f1_score(y_test, rf.predict(X_test)), "ROC-AUC": roc_auc_score(y_test, rf_prob)}
]

display(pd.DataFrame(models_bench))
"""))

cells.append(nbf.v4.new_code_cell("""# ROC Curve Comparison
plt.figure(figsize=(7, 5.5))
fpr_mlp, tpr_mlp, _ = roc_curve(y_test, y_prob_mlp)
fpr_lr, tpr_lr, _ = roc_curve(y_test, lr_prob)
fpr_rf, tpr_rf, _ = roc_curve(y_test, rf_prob)

plt.plot(fpr_mlp, tpr_mlp, color='#d9534f', linewidth=2, label=f'MLP (AUC = {auc:.3f})')
plt.plot(fpr_lr, tpr_lr, color='#2b5c8f', linestyle='--', linewidth=2, label=f'Logistic Reg (AUC = {roc_auc_score(y_test, lr_prob):.3f})')
plt.plot(fpr_rf, tpr_rf, color='#27ae60', linestyle='-.', linewidth=2, label=f'Random Forest (AUC = {roc_auc_score(y_test, rf_prob):.3f})')
plt.plot([0, 1], [0, 1], 'k:')
plt.title("ROC Curve Benchmark Comparison", fontsize=13, weight='bold')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.legend()
plt.show()
"""))

cells.append(nbf.v4.new_code_cell("""# Permutation Feature Importance for MLP
base_auc = roc_auc_score(y_test, y_prob_mlp)
drops = []
for i in range(X_test.shape[1]):
    X_shuff = X_test.copy()
    X_shuff[:, i] = np.random.permutation(X_shuff[:, i])
    drops.append(base_auc - roc_auc_score(y_test, final_model.predict(X_shuff, verbose=0).ravel()))

df_fi = pd.DataFrame({"Feature": feature_names, "AUC Drop": drops}).sort_values(by="AUC Drop", ascending=False)

plt.figure(figsize=(8, 5))
sns.barplot(data=df_fi.head(10), x='AUC Drop', y='Feature', palette='viridis')
plt.title("Top-10 MLP Permutation Feature Importance", fontsize=13, weight='bold')
plt.xlabel("Drop in ROC-AUC on Permutation")
plt.show()
"""))

# Section 11: Conclusion & Educational Disclaimer
cells.append(nbf.v4.new_markdown_cell("""## 11. Conclusion & Educational Disclaimer
### Summary of Findings:
1. **EDA & Statistical Significance:** Maximum heart rate achieved (`thalach`), ST depression (`oldpeak`), and exercise-induced angina (`exang`) exhibit strong divergence across cardiac risk cohorts ($p < 0.001$).
2. **Deep Learning vs Baselines:** Deep MLP attained **71.74% accuracy and 0.8210 ROC-AUC** on the held-out test cohort, demonstrating high specificity (85.71%) and precision (83.33%). On small clinical tabular cohorts ($N \\approx 300$), shallow linear models and random forests provide competitive performance due to parsimony.
3. **Primary Diagnostic Drivers:** Thalassemia defect type (`thal`), peak exercise ST slope (`slope`), and the number of major vessels colored by fluoroscopy (`ca`) constitute the strongest predictive signals.

---
**EDUCATIONAL USE DISCLAIMER:**  
*This software and research artifact are developed strictly for academic educational purposes as part of the B.Tech Artificial Intelligence and Data Science curriculum. Predictions generated by these models must NOT be interpreted, utilized, or relied upon as medical diagnoses, clinical guidance, or diagnostic determinations. Real-world clinical decision-making requires licensed medical professionals and certified diagnostic testing.*
"""))

nb.cells = cells

notebook_path = "notebooks/Heart_Disease_EDA_Deep_Learning.ipynb"
with open(notebook_path, "w", encoding="utf-8") as f:
    nbf.write(nb, f)

print(f"[SUCCESS] Notebook successfully generated at: {notebook_path}")
