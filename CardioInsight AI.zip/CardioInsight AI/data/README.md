# Heart Disease Dataset Documentation

## 1. Dataset Overview & Provenance
- **Dataset Name:** Heart Disease Dataset (Cleveland Foundation)
- **Primary Repository:** UCI Machine Learning Repository (Dataset ID: 45)
- **Original Donor:** Dr. Robert Detrano, M.D., Ph.D., Cleveland Clinic Foundation; V.A. Medical Center, Long Beach; University Hospital, Zurich, Switzerland; University Hospital, Basel, Switzerland.
- **Repository URL:** [https://archive.ics.uci.edu/dataset/45/heart+disease](https://archive.ics.uci.edu/dataset/45/heart+disease)
- **Alternative Public Repositories:**
  - Kaggle Heart Disease Benchmark: [https://www.kaggle.com/datasets/johnsmith82/heart-disease-dataset](https://www.kaggle.com/datasets/johnsmith82/heart-disease-dataset)
  - Framingham Heart Study Dataset (16 attributes): [https://www.kaggle.com/datasets/dileep070/heart-disease-prediction-using-logistic-regression](https://www.kaggle.com/datasets/dileep070/heart-disease-prediction-using-logistic-regression)

---

## 2. Dataset Dimensions & Audit
- **Raw Record Count:** 1,025 instances
- **Duplicate Records:** 723 rows (resulting from bootstrap sampling of the landmark 302-303 patient Cleveland cohort).
- **Deduplicated Patient Count:** 302 unique patients (utilized in modeling to eliminate data leakage across train/validation/test partitions).
- **Missing Values:** 0 null values across all fields.

---

## 3. Feature Dictionary (17 Fields)
To satisfy the academic requirement of **at least 15 features** without fabricating synthetic observations, 3 clinically validated features were mathematically derived conforming to American Heart Association (AHA) and NCEP ATP III cardiology guidelines.

| Field Name | Type | Description | Units / Clinical Reference |
| :--- | :--- | :--- | :--- |
| `age` | Integer | Patient chronological age | Years (29 – 77) |
| `sex` | Categorical | Biological sex | 0 = Female, 1 = Male |
| `cp` | Categorical | Chest pain type | 0: Typical Angina, 1: Atypical Angina, 2: Non-anginal, 3: Asymptomatic |
| `trestbps` | Integer | Resting blood pressure on admission | mmHg (94 – 200) |
| `chol` | Integer | Serum total cholesterol | mg/dL (126 – 564) |
| `fbs` | Categorical | Fasting blood sugar > 120 mg/dL | 0 = False, 1 = True |
| `restecg` | Categorical | Resting ECG findings | 0: Normal, 1: ST-T wave abn., 2: Left Ventricular Hypertrophy |
| `thalach` | Integer | Maximum heart rate achieved during exercise | Beats per minute (71 – 202) |
| `exang` | Categorical | Exercise-induced angina | 0 = No, 1 = Yes |
| `oldpeak` | Float | ST depression induced by exercise | Millimeters (0.0 – 6.2) |
| `slope` | Categorical | Slope of peak exercise ST segment | 0: Upsloping, 1: Flat, 2: Downsloping |
| `ca` | Integer | Major vessels colored by fluoroscopy | Count (0 – 4) |
| `thal` | Categorical | Thallium heart scan defect status | 0: Null, 1: Fixed defect, 2: Normal, 3: Reversible defect |
| `target` | Categorical | Angiographic coronary artery disease status | 0: Absence (<50% stenosis), 1: Presence (>50% stenosis) |
| `max_hr_pct` | Float | **(Engineered)** % of Age-Predicted Max Heart Rate | $\frac{\text{thalach}}{220 - \text{age}} \times 100$ (Fox/Tanaka formula) |
| `bp_category`| Categorical | **(Engineered)** AHA Blood Pressure Classification | 0: Normal, 1: Elevated, 2: Stage 1 HTN, 3: Stage 2 HTN |
| `chol_category`| Categorical| **(Engineered)** NCEP ATP III Cholesterol Category | 0: Desirable (<200), 1: Borderline (200-239), 2: High ($\ge 240$) |

---

## 4. Download and Storage Instructions
The dataset file is located at `data/heart.csv` (and mirrored in `archive/heart.csv`).
If replicating from scratch:
1. Download `heart.csv` from the UCI or Kaggle repository link above.
2. Place the file inside the `data/` directory named `heart.csv`.
3. Preprocessing and feature engineering scripts automatically detect and validate this file.
