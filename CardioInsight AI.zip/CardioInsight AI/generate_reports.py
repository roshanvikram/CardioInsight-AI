"""
CardioInsight AI - Complete Academic Report Generator (DOCX & PDF)
Author: Senior Data Scientist / ML Engineer
Generates:
1. reports/Project_Report.docx (using python-docx)
2. reports/Project_Report.pdf (using reportlab)
Contains all 17 mandatory sections, verified statistics, formatted tables, and embedded high-resolution figures.
"""

import os
import sys
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, PageBreak, KeepTogether, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfgen import canvas

RESULTS_DIR = "results"
REPORTS_DIR = "reports"
os.makedirs(REPORTS_DIR, exist_ok=True)

# Helper function to style docx tables
def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def create_docx_report():
    print("[INFO] Generating academic Project_Report.docx...")
    doc = Document()

    # Configure Margins (1 inch all around)
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)

    # Styles
    normal_style = doc.styles['Normal']
    normal_style.font.name = 'Times New Roman'
    normal_style.font.size = Pt(11)
    normal_style.font.color.rgb = RGBColor(30, 30, 30)

    # -------------------------------------------------------------
    # 1. TITLE PAGE
    # -------------------------------------------------------------
    p_title_space = doc.add_paragraph()
    p_title_space.paragraph_format.space_before = Pt(36)

    p_inst = doc.add_paragraph()
    p_inst.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_inst = p_inst.add_run("KPR INSTITUTE OF ENGINEERING AND TECHNOLOGY\nDEPARTMENT OF ARTIFICIAL INTELLIGENCE AND DATA SCIENCE\nACADEMIC PROJECT REPORT - 2026")
    run_inst.font.size = Pt(13)
    run_inst.font.bold = True
    run_inst.font.color.rgb = RGBColor(43, 92, 143)

    doc.add_paragraph().paragraph_format.space_after = Pt(24)

    p_proj = doc.add_paragraph()
    p_proj.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_proj = p_proj.add_run("EXPLORATORY DATA ANALYSIS AND VISUALIZATION OF HEART DISEASE USING STATISTICAL ANALYSIS AND DEEP LEARNING")
    run_proj.font.size = Pt(18)
    run_proj.font.bold = True
    run_proj.font.color.rgb = RGBColor(20, 20, 20)

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_sub = p_sub.add_run("A Capstone Project Submitted in Partial Fulfillment of the Requirements for the Degree of\nBachelor of Technology (B.Tech) in Artificial Intelligence & Data Science")
    run_sub.font.size = Pt(11)
    run_sub.font.italic = True
    p_sub.paragraph_format.space_after = Pt(40)

    p_meta = doc.add_paragraph()
    p_meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_meta.add_run("Submitted By:\n").bold = True
    p_meta.add_run("STUDENT NAME: ROSHAN VIKRAM A V\n")
    p_meta.add_run("ROLL NUMBER: 25ADL09\n")
    p_meta.add_run("DEPARTMENT: Department of Artificial Intelligence and Data Science\n")
    p_meta.add_run("PROGRAM: B.Tech in Artificial Intelligence & Data Science\n\n")
    p_meta.add_run("Institution & Submission Details:\n").bold = True
    p_meta.add_run("INSTITUTION: KPR Institute of Engineering and Technology\n")
    p_meta.add_run("ACADEMIC YEAR: 2025–2026\n")
    p_meta.add_run("SUBMISSION DATE: 15.10.2026 (15th October 2026)\n")

    doc.add_page_break()

    # -------------------------------------------------------------
    # ABSTRACT
    # -------------------------------------------------------------
    h_abs = doc.add_heading("ABSTRACT", level=1)
    h_abs.paragraph_format.space_before = Pt(12)
    p_abs = doc.add_paragraph(
        "Cardiovascular diseases (CVDs) remain the primary contributor to global morbidity and mortality, "
        "accounting for an estimated 17.9 million annual fatalities worldwide. Early, non-invasive risk detection "
        "is paramount for effective preventive clinical interventions. This academic study investigates heart disease "
        "pathology by applying exploratory data analysis, formal inferential statistics, and deep neural network modeling "
        "to the landmark UCI Heart Disease dataset. Grounded in a systematic Seven Stages of Visualization methodology, "
        "the raw clinical dataset (1,025 records) underwent deduplication (retaining 302 unique patient instances) "
        "and clinical feature engineering conforming to American Heart Association (AHA) and NCEP ATP III guidelines, "
        "expanding the analytical space to 17 structured attributes. Statistical hypothesis testing confirmed significant "
        "pathological divergence in maximum heart rate (t = -14.86, p < 0.001) and exercise ST depression (t = 15.41, p < 0.001). "
        "A Deep Multilayer Perceptron (MLP) was constructed in TensorFlow/Keras, systematically optimized across 5 hyperparameter "
        "architectures, and evaluated on an isolated held-out test cohort (15%). The optimized MLP achieved 71.74% accuracy, 83.33% precision, "
        "85.71% specificity, and an ROC-AUC of 0.8210, benchmarked against Logistic Regression and Random Forest models. "
        "Permutation importance identified peak ST slope, fluoroscopy vessel coloration, and thalassemia defects as leading predictive indicators."
    )
    p_abs.paragraph_format.line_spacing = 1.15
    doc.add_paragraph("Keywords: Heart Disease, Exploratory Data Analysis, Deep Learning, Multilayer Perceptron, Medical Informatics, Seven Stages of Visualization, ROC-AUC.")
    doc.add_page_break()

    # -------------------------------------------------------------
    # TABLE OF CONTENTS
    # -------------------------------------------------------------
    doc.add_heading("TABLE OF CONTENTS", level=1)
    toc_items = [
        ("1.0 Introduction", "Background, Problem Statement, Objectives, Scope"),
        ("2.0 Literature Review", "Academic Survey of Clinical Decision Support & ML in Cardiology"),
        ("3.0 Dataset Description & Preprocessing", "Source, Deduplication, Clinical Engineering (17 Fields)"),
        ("4.0 The Seven Stages of Visualization", "Framework Mapping from Acquisition to Communication"),
        ("5.0 Exploratory Data Analysis (EDA)", "Univariate, Distribution, Bivariate & Multivariate Analysis"),
        ("6.0 Data Visualization Gallery", "In-Depth Discussion of Core Clinical Visualizations"),
        ("7.0 Deep Learning Model Architecture", "MLP Design, Regularization, Loss Function & Optimization"),
        ("8.0 Hyperparameter Tuning Experiments", "Systematic Validation Experiments & Selection Criteria"),
        ("9.0 Results and Discussion", "Test Set Metrics, Confusion Matrix, ROC-AUC & Baseline Comparison"),
        ("10.0 Feature Importance Analysis", "Permutation Importance & Collinearity Interpretation"),
        ("11.0 Limitations & Educational Disclaimer", "Sample Constraints, Model Scope & Clinical Disclaimer"),
        ("12.0 Conclusion & Future Scope", "Synthesis of Findings, Technical Insights & Future Work"),
        ("13.0 References", "Formal Academic Citations in IEEE Style"),
        ("14.0 Appendix: Source Code & Execution Guide", "Execution Instructions & Technical Architecture")
    ]
    toc_table = doc.add_table(rows=1, cols=2)
    toc_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr_cells = toc_table.rows[0].cells
    hdr_cells[0].text = "Section / Topic"
    hdr_cells[1].text = "Description / Coverage"
    set_cell_background(hdr_cells[0], "2B5C8F")
    set_cell_background(hdr_cells[1], "2B5C8F")
    hdr_cells[0].paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
    hdr_cells[1].paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
    hdr_cells[0].paragraphs[0].runs[0].font.bold = True
    hdr_cells[1].paragraphs[0].runs[0].font.bold = True

    for sec, desc in toc_items:
        row = toc_table.add_row().cells
        row[0].text = sec
        row[1].text = desc
        row[0].paragraphs[0].runs[0].font.bold = True
        set_cell_margins(row[0], 60, 60, 100, 100)
        set_cell_margins(row[1], 60, 60, 100, 100)

    doc.add_page_break()

    # Helper function for adding headings and content
    def add_section(num_title, text):
        h = doc.add_heading(num_title, level=1)
        h.paragraph_format.space_before = Pt(14)
        h.paragraph_format.space_after = Pt(6)
        p = doc.add_paragraph(text)
        p.paragraph_format.line_spacing = 1.15
        p.paragraph_format.space_after = Pt(8)
        return p

    # -------------------------------------------------------------
    # 1.0 INTRODUCTION
    # -------------------------------------------------------------
    add_section("1.0 INTRODUCTION", 
        "1.1 Background\n"
        "Cardiovascular disease represents an intricate group of pathological disorders affecting the heart and vascular "
        "system, encompassing coronary artery disease, heart failure, cerebrovascular disease, and cardiomyopathy. According "
        "to the World Health Organization, ischemic heart disease accounted for approximately 16% of all deaths globally. "
        "Conventional diagnostic procedures, including coronary angiography, are invasive, resource-intensive, and carry clinical risks. "
        "Consequently, there is considerable interest in developing non-invasive computational methodologies leveraging machine learning "
        "and artificial intelligence to extract diagnostic indicators from baseline physiological and exercise stress testing parameters.\n\n"
        "1.2 Problem Statement\n"
        "While numerous machine learning pipelines exist, many suffer from three pervasive flaws in academic literature: "
        "(a) uncontrolled data leakage caused by training on duplicated patient cohorts without strict partitioning, "
        "(b) failure to perform rigorous exploratory distribution testing and inferential hypothesis verification, and "
        "(c) presenting unregularized deep neural models without transparent baseline benchmarking. This project aims to address "
        "these shortcomings by providing a mathematically grounded, leak-free exploratory data analysis and deep learning classification system.\n\n"
        "1.3 Project Objectives\n"
        "The primary objectives of this research project are:\n"
        "1. Ingest, audit, and clean the landmark UCI Heart Disease dataset while expanding the analytical feature space to 17 fields "
        "through evidence-based clinical feature derivation.\n"
        "2. Conduct comprehensive univariate, bivariate, and multivariate exploratory data analysis, accompanied by statistical hypothesis testing.\n"
        "3. Design and implement the Seven Stages of Visualization pipeline to synthesize meaningful medical visual encodings.\n"
        "4. Construct, regularize, and systematically tune a Deep Multilayer Perceptron (MLP) classification network using TensorFlow/Keras.\n"
        "5. Objectively benchmark the deep neural network against linear (Logistic Regression) and ensemble (Random Forest) baselines on a held-out test cohort.\n"
        "6. Perform permutation feature importance analysis to explain model predictions.\n\n"
        "1.4 Scope and Educational Nature\n"
        "This project is developed strictly for educational and academic evaluation purposes within the B.Tech Artificial Intelligence "
        "and Data Science curriculum. It does not provide clinical medical diagnoses or therapeutic instructions."
    )

    # -------------------------------------------------------------
    # 2.0 LITERATURE REVIEW
    # -------------------------------------------------------------
    add_section("2.0 LITERATURE REVIEW",
        "The intersection of computational cardiology and machine learning has evolved over four decades. "
        "Detrano et al. (1989) pioneered the Cleveland Heart Disease study, establishing the foundational dataset used in modern "
        "biomedical benchmark evaluations. Their work demonstrated that exercise-induced thallium scintigraphy and fluoroscopy of major vessels "
        "yielded discriminatory power superior to resting electrocardiography alone.\n\n"
        "Tanaka, Monahan, and Seals (2001) re-examined age-predicted maximal heart rate equations across 351 clinical studies ($N = 18,712$), "
        "validating the cardiovascular reserve metric (Max HR = 220 - age) and establishing its vital role in detecting chronotropic incompetence.\n\n"
        "In modern machine learning, LeCun, Bengio, and Hinton (2015) outlined deep learning principles, noting that while deep networks excel "
        "in capturing non-linear interactions, tabular biomedical datasets characterized by limited sample sizes ($N < 1,000$) require strict "
        "regularization (Dropout, L2 decay, Batch Normalization) to mitigate overfitting. Fernandez-Delgado et al. (2014) conducted an exhaustive "
        "benchmark across 179 classifiers on UCI datasets, confirming that random forests and regularized shallow networks often match or outperform "
        "deep neural networks on tabular clinical data due to bounded hypothesis complexity.\n\n"
        "Furthermore, Shneiderman (1996) and Kirk (2016) proposed structured visualization frameworks emphasizing visual information seeking "
        "from high-level overview to filtered details, providing the theoretical basis for our Seven Stages of Visualization."
    )

    # -------------------------------------------------------------
    # 3.0 DATASET DESCRIPTION & PREPROCESSING
    # -------------------------------------------------------------
    add_section("3.0 DATASET DESCRIPTION & DATA PREPROCESSING",
        "3.1 Dataset Source and Verification\n"
        "The project utilizes the landmark Heart Disease dataset sourced from the UCI Machine Learning Repository (Dataset ID: 45), "
        "originally curated by Dr. Robert Detrano (Cleveland Clinic Foundation). The primary distribution archived in our workspace "
        "(`data/heart.csv` / `archive/heart.csv`) comprises 1,025 raw observations.\n\n"
        "3.2 Feature Expansion (17 Clinical Fields)\n"
        "To satisfy the academic requirement of at least 15 features without fabricating synthetic patient observations, "
        "we engineer three clinically validated cardiovascular indices grounded in established medical consensus:\n"
        "1. `max_hr_pct`: Percentage of age-predicted maximum heart rate (Tanaka/Fox formula: thalach / (220 - age) * 100).\n"
        "2. `bp_category`: American Heart Association (AHA) blood pressure staging (0: Normal, 1: Elevated, 2: Stage 1 HTN, 3: Stage 2 HTN).\n"
        "3. `chol_category`: National Cholesterol Education Program (NCEP ATP III) cholesterol risk classification (0: Desirable, 1: Borderline, 2: High).\n"
        "Together with the 14 raw clinical variables, this expands the dataset to 17 structured fields."
    )

    # Table 1: Feature Description Table
    doc.add_paragraph("Table 1: Feature Dictionary and Clinical Definition (17 Fields)").runs[0].font.bold = True
    t_feat = doc.add_table(rows=1, cols=4)
    t_feat.alignment = WD_TABLE_ALIGNMENT.CENTER
    th = t_feat.rows[0].cells
    th[0].text, th[1].text, th[2].text, th[3].text = "Field Name", "Type", "Clinical Meaning", "Units / Domain Values"
    for c in th:
        set_cell_background(c, "2B5C8F")
        c.paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
        c.paragraphs[0].runs[0].font.bold = True

    features_meta = [
        ("age", "Integer", "Patient chronological age", "Years (29 - 77)"),
        ("sex", "Categorical", "Biological sex", "0 = Female, 1 = Male"),
        ("cp", "Categorical", "Chest pain type", "0: Typical, 1: Atypical, 2: Non-anginal, 3: Asymptomatic"),
        ("trestbps", "Integer", "Resting blood pressure on hospital admission", "mmHg (94 - 200)"),
        ("chol", "Integer", "Serum total cholesterol", "mg/dL (126 - 564)"),
        ("fbs", "Categorical", "Fasting blood sugar > 120 mg/dL", "0 = False, 1 = True"),
        ("restecg", "Categorical", "Resting electrocardiographic results", "0: Normal, 1: ST-T wave abn., 2: LVH"),
        ("thalach", "Integer", "Maximum heart rate achieved during exercise", "Beats per minute (71 - 202)"),
        ("exang", "Categorical", "Exercise-induced angina", "0 = No, 1 = Yes"),
        ("oldpeak", "Float", "ST depression induced by exercise relative to rest", "Millimeters (0.0 - 6.2)"),
        ("slope", "Categorical", "Slope of peak exercise ST segment", "0: Upsloping, 1: Flat, 2: Downsloping"),
        ("ca", "Integer", "Number of major vessels colored by fluoroscopy", "Count (0 - 4)"),
        ("thal", "Categorical", "Thallium heart scan defect status", "0: Null, 1: Fixed, 2: Normal, 3: Reversible"),
        ("target", "Categorical", "Angiographic coronary artery disease status", "0: <50% stenosis, 1: >50% stenosis"),
        ("max_hr_pct", "Float (Engineered)", "% of age-predicted maximum heart rate", "Percentage (46.4% - 117.5%)"),
        ("bp_category", "Categorical (Eng.)", "AHA blood pressure classification", "0: Normal, 1: Elevated, 2: Stg 1, 3: Stg 2"),
        ("chol_category", "Categorical (Eng.)", "NCEP ATP III cholesterol risk category", "0: Desirable, 1: Borderline, 2: High")
    ]
    for fn, tp, cm, dm in features_meta:
        row = t_feat.add_row().cells
        row[0].text, row[1].text, row[2].text, row[3].text = fn, tp, cm, dm
        for c in row:
            set_cell_margins(c, 40, 40, 80, 80)

    # 3.3 Deduplication and Leakage Prevention
    p_dedup = doc.add_paragraph(
        "\n3.3 Deduplication & Strict Leakage Prevention\n"
        "The raw 1,025-record archive contains 723 duplicate instances arising from bootstrap re-sampling of the original "
        "Cleveland cohort ($N = 302$ unique patients). Training and testing on resampled duplicates without deduplication constitutes "
        "a critical flaw (data leakage) that artificially inflates test accuracy. Therefore, deduplication was performed, isolating "
        "302 unique patients. The cohort was partitioned using stratified sampling into:\n"
        "• Training Cohort: 211 patients (69.9%)\n"
        "• Validation Cohort: 45 patients (14.9%)\n"
        "• Held-Out Testing Cohort: 46 patients (15.2%)\n"
        "All standardization transformations (`StandardScaler`) were fitted exclusively on the Training Cohort and applied to validation and test sets."
    )
    p_dedup.paragraph_format.line_spacing = 1.15

    # -------------------------------------------------------------
    # 4.0 THE SEVEN STAGES OF VISUALIZATION
    # -------------------------------------------------------------
    add_section("4.0 THE SEVEN STAGES OF VISUALIZATION",
        "To ensure systematic data analysis, we explicitly map the project implementation to the established Seven Stages of Visualization "
        "methodology formulated by Ben Fry (2004) and Colin Ware (2012):\n\n"
        "1. Stage 1: ACQUIRE — Ingestion of the genuine raw 1,025-record cardiovascular dataset from the official archive directory.\n"
        "2. Stage 2: PARSE — Structural decoding, schema identification, data typing, and missingness audit (0 missing values confirmed).\n"
        "3. Stage 3: FILTER — Elimination of 723 duplicated records to prevent split contamination; IQR-based outlier boundary calculation.\n"
        "4. Stage 4: MINE — Mathematical extraction of statistical distributions, inferential hypothesis testing (t-tests, Chi-square), "
        "and clinical index feature derivation (17 fields).\n"
        "5. Stage 5: REPRESENT — Selection of appropriate visual encodings (boxplots with jitter for dispersion, heatmaps for bivariate "
        "correlations, violin plots for multivariable interactions, and ROC curves for model discrimination).\n"
        "6. Stage 6: REFINE — Aesthetic polish, contrasting accessible color palettes (#2B5C8F and #D9534F), typography, data labels, and 300 DPI rendering.\n"
        "7. Stage 7: INTERACT & COMMUNICATE — Translation of graphical observations into actionable clinical risk findings, acknowledging diagnostic limitations."
    )

    # -------------------------------------------------------------
    # 5.0 EXPLORATORY DATA ANALYSIS (EDA)
    # -------------------------------------------------------------
    add_section("5.0 EXPLORATORY DATA ANALYSIS (EDA) & STATISTICAL FINDINGS",
        "5.1 Univariate Statistical Analysis\n"
        "Descriptive statistics were computed across all continuous variables, assessing central tendency, dispersion, and asymmetry."
    )

    # Table 2: Univariate Stats Table
    doc.add_paragraph("Table 2: Univariate Descriptive Statistics of Continuous Cardiovascular Measurements").runs[0].font.bold = True
    t_univ = doc.add_table(rows=1, cols=8)
    t_univ.alignment = WD_TABLE_ALIGNMENT.CENTER
    th2 = t_univ.rows[0].cells
    th2[0].text, th2[1].text, th2[2].text, th2[3].text, th2[4].text, th2[5].text, th2[6].text, th2[7].text = (
        "Feature", "Mean", "Median", "Std Dev", "Min", "Max", "IQR", "Skewness"
    )
    for c in th2:
        set_cell_background(c, "2B5C8F")
        c.paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
        c.paragraphs[0].runs[0].font.bold = True

    univ_data = [
        ("age", "54.43", "56.00", "9.07", "29.0", "77.0", "13.0", "-0.249"),
        ("trestbps", "131.61", "130.00", "17.52", "94.0", "200.0", "20.0", "0.740"),
        ("chol", "246.00", "240.00", "51.59", "126.0", "564.0", "64.0", "1.074"),
        ("thalach", "149.11", "152.00", "23.01", "71.0", "202.0", "34.0", "-0.514"),
        ("oldpeak", "1.07", "0.80", "1.18", "0.0", "6.2", "1.8", "1.211"),
        ("max_hr_pct", "90.04", "92.76", "12.89", "46.4", "117.5", "17.2", "-0.653")
    ]
    for row_vals in univ_data:
        r = t_univ.add_row().cells
        for idx, val in enumerate(row_vals):
            r[idx].text = val
            set_cell_margins(r[idx], 40, 40, 60, 60)

    # 5.2 Bivariate Hypothesis Testing
    p_biv = doc.add_paragraph(
        "\n5.2 Bivariate Inferential Hypothesis Testing\n"
        "Two-sample independent Student's t-tests (with Welch's correction) and Mann-Whitney U tests were performed to determine whether "
        "continuous physiological markers differ significantly between healthy patients (target = 0) and heart disease patients (target = 1). "
        "Categorical dependencies were evaluated using Pearson's Chi-Square Test of Independence."
    )
    p_biv.paragraph_format.line_spacing = 1.15

    # Table 3: Hypothesis Testing Table
    doc.add_paragraph("Table 3: Inferential Hypothesis Testing (Continuous & Categorical Parameters)").runs[0].font.bold = True
    t_hyp = doc.add_table(rows=1, cols=5)
    t_hyp.alignment = WD_TABLE_ALIGNMENT.CENTER
    th3 = t_hyp.rows[0].cells
    th3[0].text, th3[1].text, th3[2].text, th3[3].text, th3[4].text = "Feature", "Mean (No Disease)", "Mean (Disease)", "Test Statistic", "p-value (Significance)"
    for c in th3:
        set_cell_background(c, "2B5C8F")
        c.paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
        c.paragraphs[0].runs[0].font.bold = True

    hyp_data = [
        ("age", "56.57 yrs", "52.41 yrs", "t = 7.574", "8.18e-14 (p < 0.001)"),
        ("trestbps", "134.11 mmHg", "129.25 mmHg", "t = 4.465", "8.92e-06 (p < 0.001)"),
        ("chol", "251.29 mg/dL", "240.98 mg/dL", "t = 3.219", "1.33e-03 (p < 0.01)"),
        ("thalach", "139.13 bpm", "158.59 bpm", "t = -14.862", "3.42e-45 (p < 0.001)"),
        ("oldpeak", "1.60 mm", "0.57 mm", "t = 15.409", "3.87e-47 (p < 0.001)"),
        ("max_hr_pct", "85.24%", "94.59%", "t = -12.328", "2.40e-32 (p < 0.001)"),
        ("sex (M/F)", "Categorical", "Categorical", "Chi2 = 78.86", "6.66e-19 (p < 0.001)"),
        ("cp (Chest Pain)", "Categorical", "Categorical", "Chi2 = 280.98", "1.30e-60 (p < 0.001)"),
        ("fbs (Fasting Sugar)", "Categorical", "Categorical", "Chi2 = 1.513", "0.2186 (Not Significant)"),
        ("exang (Angina)", "Categorical", "Categorical", "Chi2 = 194.82", "2.83e-44 (p < 0.001)"),
        ("slope (ST Slope)", "Categorical", "Categorical", "Chi2 = 155.87", "1.42e-34 (p < 0.001)"),
        ("ca (Fluoroscopy)", "Categorical", "Categorical", "Chi2 = 257.29", "1.75e-54 (p < 0.001)"),
        ("thal (Thallium)", "Categorical", "Categorical", "Chi2 = 280.33", "1.80e-60 (p < 0.001)")
    ]
    for r_vals in hyp_data:
        r = t_hyp.add_row().cells
        for idx, val in enumerate(r_vals):
            r[idx].text = val
            set_cell_margins(r[idx], 35, 35, 60, 60)

    # -------------------------------------------------------------
    # 6.0 DATA VISUALIZATION GALLERY
    # -------------------------------------------------------------
    add_section("6.0 DATA VISUALIZATION GALLERY (EDA PLOTS)",
        "In accordance with project guidelines, this section documents all generated high-resolution visualizations. "
        "For each figure, the clinical rationale, observations, and analytical interpretations are provided."
    )

    def insert_figure(img_filename, fig_num, title, rationale, observation, interpretation, limitations, width=5.8):
        img_path = os.path.join(RESULTS_DIR, img_filename)
        if os.path.exists(img_path):
            doc.add_paragraph().paragraph_format.space_before = Pt(8)
            p_img = doc.add_paragraph()
            p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p_img.add_run().add_picture(img_path, width=Inches(width))
            
            p_cap = doc.add_paragraph()
            p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run_cap = p_cap.add_run(f"Figure {fig_num}: {title}")
            run_cap.font.bold = True
            run_cap.font.size = Pt(10)
            
            p_desc = doc.add_paragraph()
            p_desc.paragraph_format.line_spacing = 1.15
            p_desc.add_run("• What the Graph Represents & Selection Rationale: ").bold = True
            p_desc.add_run(rationale + "\n")
            p_desc.add_run("• Actual Observation from Data: ").bold = True
            p_desc.add_run(observation + "\n")
            p_desc.add_run("• Clinical / Practical Interpretation: ").bold = True
            p_desc.add_run(interpretation + "\n")
            p_desc.add_run("• Limitations: ").bold = True
            p_desc.add_run(limitations + "\n")
        else:
            doc.add_paragraph(f"[Image {img_filename} not found in results directory]")

    insert_figure(
        "01_target_distribution.png", 1, "Target Class Distribution (Heart Disease Prevalence)",
        "Bar count plot illustrating the frequency and percentage breakdown of normal subjects versus coronary disease patients.",
        "In the raw cohort, 526 patients (51.3%) presented with heart disease, while 499 patients (48.7%) had absence of disease.",
        "The class distribution is balanced, preventing severe class-imbalance bias during neural network training.",
        "Reflects hospital referral incidence rather than general asymptomatic population prevalence."
    )

    insert_figure(
        "02_age_distribution.png", 2, "Age Distribution Stratified by Heart Disease Status",
        "Histogram with superimposed Kernel Density Estimation (KDE) curves stratified by target class.",
        "Heart disease prevalence shows a high concentration between 50 and 62 years, with mean cohort age at 54.43 years.",
        "Demonstrates that risk rises progressively during the fifth and sixth decades of life.",
        "Limited representation of pediatric cohorts and octogenarians."
    )

    insert_figure(
        "03_correlation_heatmap.png", 3, "Pearson Correlation Heatmap of Key Cardiac Measurements",
        "Triangular annotated correlation matrix heatmap depicting linear interrelationships between numerical features and disease status.",
        "Thalach exhibits strong positive correlation with target (+0.42), while oldpeak exhibits strong negative correlation (-0.44).",
        "Confirms that exercise capacity and ST segment depression are dominant bivariate linear predictors.",
        "Pearson correlation measures only linear relationships; non-linear associations require neural representations."
    )

    insert_figure(
        "04_thalach_boxplot.png", 4, "Maximum Heart Rate Achieved (thalach) Stratified by Disease Status",
        "Boxplot paired with jittered stripplot comparing heart rate distributions between healthy and cardiac patients.",
        "Median maximum heart rate for patients with disease is significantly higher (161 bpm) than without disease (142 bpm) (t = -14.86, p < 0.001).",
        "Higher achieved exercise heart rate in this specific cohort is inversely associated with severe angiographic stenosis.",
        "Heavily influenced by patient exercise protocol tolerance and beta-blocker medication."
    )

    insert_figure(
        "05_age_vs_thalach_scatter.png", 5, "Age vs. Maximum Heart Rate (thalach) with Stratified Regression Trendlines",
        "Scatterplot showing age vs thalach with linear regression trendlines and 95% confidence intervals across disease states.",
        "Both healthy and diseased patients exhibit expected age-related decline in max heart rate, but disease patients maintain an elevated baseline across ages.",
        "Validates the Tanaka/Fox age-predicted cardiac reserve degradation while highlighting group separation.",
        "Cross-sectional snapshot rather than longitudinal patient tracking."
    )

    insert_figure(
        "06_pairplot_selected_features.png", 6, "Pairwise Feature Interactions Across Key Diagnostic Measurements",
        "Pairplot of age, resting BP, cholesterol, thalach, and oldpeak hue-coded by heart disease status.",
        "Bivariate clusters show pronounced separation between oldpeak (ST depression) and thalach (heart rate), forming distinct diagnostic manifolds.",
        "Highlights multi-dimensional non-linear boundaries that justify deep learning Multilayer Perceptrons over single-variable thresholds.",
        "High dimensionality makes simultaneous 5D visual inspection challenging."
    )

    insert_figure(
        "07_chest_pain_analysis.png", 7, "Heart Disease Prevalence Across Chest Pain Types (cp)",
        "Stacked bar chart showing proportion of heart disease across chest pain classifications (0 to 3).",
        "Non-anginal pain (type 2) and atypical angina (type 1) exhibit disease rates exceeding 75%, whereas typical angina (type 0) has under 30%.",
        "Subjective clinical pain descriptions require objective ECG corroboration due to atypical presentation in diabetic and female patients.",
        "Chest pain descriptions are subjective and clinician-dependent."
    )

    insert_figure(
        "08_st_depression_slope_analysis.png", 8, "ST Depression (oldpeak) Distribution by Peak Exercise ST Slope",
        "Split violin plot illustrating ST depression distribution across upsloping, flat, and downsloping ST segment geometries.",
        "Patients with flat slopes (slope = 1) exhibit significantly higher ST depression medians in cardiac disease subjects.",
        "Demonstrates the physiological link between myocardial ischemia and abnormal repolarization slopes.",
        "Requires resting ECG baseline for precise ST-segment depression measurement."
    )

    # -------------------------------------------------------------
    # 7.0 DEEP LEARNING MODEL ARCHITECTURE
    # -------------------------------------------------------------
    add_section("7.0 DEEP LEARNING MODEL ARCHITECTURE",
        "7.1 Architecture Design\n"
        "A Multilayer Perceptron (MLP) was implemented using TensorFlow/Keras. The network accepts the 16 preprocessed features "
        "and maps them through non-linear hidden representations to a calibrated probability of coronary artery disease:\n"
        "• Input Layer: 16 input units corresponding to standardized clinical features.\n"
        "• Hidden Layer 1: Dense (64 neurons, ReLU activation, He Normal initialization, L2 weight regularization = 0.001).\n"
        "• Batch Normalization Layer: Stabilizes hidden activations and accelerates gradient convergence.\n"
        "• Dropout Layer 1: Dropout rate = 0.20 to prevent co-adaptation of hidden features.\n"
        "• Hidden Layer 2: Dense (32 neurons, ReLU activation, L2 regularization = 0.001).\n"
        "• Dropout Layer 2: Dropout rate = 0.10.\n"
        "• Hidden Layer 3: Dense (16 neurons, ReLU activation).\n"
        "• Output Layer: Dense (1 neuron, Sigmoid activation function for binary probability estimation).\n\n"
        "7.2 Optimization and Regularization Strategy\n"
        "• Loss Function: Binary Cross-Entropy Loss: L(y, p) = -[y * log(p) + (1 - y) * log(1 - p)].\n"
        "• Optimizer: Adam (Adaptive Moment Estimation) with initial learning rate = 0.001.\n"
        "• Early Stopping Callback: Monitored validation loss with patience = 12 epochs, restoring best weights.\n"
        "• Learning Rate Scheduling: ReduceLROnPlateau callback (reduction factor = 0.5, patience = 5, min_lr = 1e-5)."
    )

    # -------------------------------------------------------------
    # 8.0 HYPERPARAMETER TUNING EXPERIMENTS
    # -------------------------------------------------------------
    add_section("8.0 HYPERPARAMETER TUNING EXPERIMENTS",
        "To identify the optimal network configuration without test set contamination, five systematic architectural experiments "
        "were evaluated strictly on the Validation Set (15% split). Hyperparameters varied included hidden unit capacity, learning rate, "
        "dropout probability, and batch size."
    )

    doc.add_paragraph("Table 4: Hyperparameter Tuning Experiment Results on Validation Cohort").runs[0].font.bold = True
    t_tune = doc.add_table(rows=1, cols=7)
    t_tune.alignment = WD_TABLE_ALIGNMENT.CENTER
    th4 = t_tune.rows[0].cells
    th4[0].text, th4[1].text, th4[2].text, th4[3].text, th4[4].text, th4[5].text, th4[6].text = (
        "Experiment", "Architecture", "LR", "Dropout", "Batch", "Val Loss", "Val AUC"
    )
    for c in th4:
        set_cell_background(c, "2B5C8F")
        c.paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
        c.paragraphs[0].runs[0].font.bold = True

    tune_data = [
        ("Exp 1: Baseline MLP", "(64, 32, 16)", "0.0010", "0.20", "16", "0.5521", "0.9008"),
        ("Exp 2: Wider Capacity", "(128, 64, 32)", "0.0010", "0.30", "16", "0.7895", "0.9038"),
        ("Exp 3: Reduced LR", "(64, 32, 16)", "0.0003", "0.20", "16", "0.5614", "0.9048"),
        ("Exp 4: Larger Batch", "(64, 32, 16)", "0.0010", "0.20", "32", "0.5009", "0.9276 [Selected]"),
        ("Exp 5: Light Reg.", "(64, 32, 16)", "0.0010", "0.10", "16", "0.5852", "0.8889")
    ]
    for r_vals in tune_data:
        r = t_tune.add_row().cells
        for idx, val in enumerate(r_vals):
            r[idx].text = val
            set_cell_margins(r[idx], 35, 35, 50, 50)

    doc.add_paragraph(
        "\nSelection Justification: Experiment 4 (Batch Size = 32, LR = 0.001) achieved the lowest validation loss (0.5009) "
        "and highest Validation AUC (0.9276), outperforming smaller batch configurations which exhibited oscillatory gradient updates. "
        "Experiment 4 was accordingly selected for final evaluation."
    )

    # -------------------------------------------------------------
    # 9.0 RESULTS AND DISCUSSION
    # -------------------------------------------------------------
    add_section("9.0 RESULTS AND DISCUSSION",
        "9.1 Final Model Evaluation on Held-Out Test Set\n"
        "The selected MLP was evaluated on the completely isolated held-out test cohort (46 patients). "
        "Evaluation metrics include Accuracy, Precision (Positive Predictive Value), Recall (Sensitivity), "
        "Specificity (True Negative Rate), F1-Score, and Receiver Operating Characteristic Area Under the Curve (ROC-AUC)."
    )

    insert_figure(
        "eval_training_validation_loss.png", 9, "Training and Validation Loss Across Epochs",
        "Line plot tracking Binary Cross-Entropy loss on training and validation cohorts over 50 epochs.",
        "Validation loss reached its global minimum (0.5009) around epoch 32 before early stopping triggered at epoch 44.",
        "Demonstrates effective regularization preventing runaway catastrophic overfitting on tabular data.",
        "Stepwise improvements correlate with scheduled learning rate reductions."
    )

    insert_figure(
        "eval_training_validation_accuracy.png", 10, "Training and Validation Accuracy Across Epochs",
        "Learning curves demonstrating training accuracy vs validation accuracy progression.",
        "Training accuracy stabilized near 91.5%, while validation accuracy peaked at 84.44% before settling at 75.56%.",
        "Reflects expected generalization gap in small biomedical datasets.",
        "Subject to batch sampling variance in validation evaluations."
    )

    insert_figure(
        "eval_confusion_matrix.png", 11, "Confusion Matrix on Held-Out Test Cohort (MLP)",
        "Annotated 2x2 confusion matrix showing True Negatives, False Positives, False Negatives, and True Positives.",
        "Out of 46 test patients, the model correctly identified 18 True Negatives and 15 True Positives, with 3 False Positives and 10 False Negatives.",
        "Yields a high specificity of 85.71% and precision of 83.33%, demonstrating high reliability when predicting disease presence.",
        "Clinical deployment requires minimizing False Negatives (higher sensitivity) via decision threshold adjustment."
    )

    insert_figure(
        "eval_roc_curve.png", 12, "Receiver Operating Characteristic (ROC) Comparison",
        "Comparison of ROC curves and AUC scores across MLP, Logistic Regression, and Random Forest models.",
        "The Deep MLP attained an ROC-AUC of 0.8210, Logistic Regression attained 0.8438, and Random Forest attained 0.8305.",
        "All three models demonstrate strong discriminative power substantially exceeding random guessing (AUC = 0.50).",
        "ROC curves evaluate threshold-independent discrimination but do not reflect calibration."
    )

    insert_figure(
        "eval_precision_recall_curve.png", 13, "Precision-Recall Curve - Test Set Evaluation",
        "Precision-Recall trade-off curve across varying classification thresholds with Average Precision (AP) metric.",
        "The model maintains precision above 80% across recall values up to 0.60, with an Average Precision of 0.814.",
        "Indicates strong utility in clinical screening contexts where false alarm minimization is prioritized.",
        "In screening scenarios, lower thresholds may be preferred to boost recall."
    )

    # 9.2 Baseline Model Benchmarking
    doc.add_paragraph("Table 5: Objective Model Benchmarking on Identical Held-Out Test Cohort (46 Patients)").runs[0].font.bold = True
    t_bench = doc.add_table(rows=1, cols=7)
    t_bench.alignment = WD_TABLE_ALIGNMENT.CENTER
    th5 = t_bench.rows[0].cells
    th5[0].text, th5[1].text, th5[2].text, th5[3].text, th5[4].text, th5[5].text, th5[6].text = (
        "Model Architecture", "Accuracy", "Precision", "Recall", "Specificity", "F1-Score", "ROC-AUC"
    )
    for c in th5:
        set_cell_background(c, "2B5C8F")
        c.paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
        c.paragraphs[0].runs[0].font.bold = True

    bench_data = [
        ("MLP Neural Network", "0.7174 (71.7%)", "0.8333 (83.3%)", "0.6000 (60.0%)", "0.8571 (85.7%)", "0.6977", "0.8210"),
        ("Logistic Regression", "0.7391 (73.9%)", "0.8421 (84.2%)", "0.6400 (64.0%)", "0.8571 (85.7%)", "0.7273", "0.8438"),
        ("Random Forest", "0.7391 (73.9%)", "0.8421 (84.2%)", "0.6400 (64.0%)", "0.8571 (85.7%)", "0.7273", "0.8305")
    ]
    for r_vals in bench_data:
        r = t_bench.add_row().cells
        for idx, val in enumerate(r_vals):
            r[idx].text = val
            set_cell_margins(r[idx], 35, 35, 50, 50)

    insert_figure(
        "eval_model_comparison.png", 14, "Benchmarking Evaluation Metrics Across Architectures",
        "Grouped bar chart comparing Accuracy, Precision, Recall, F1, and AUC between MLP, Logistic Regression, and Random Forest.",
        "Logistic Regression and Random Forest slightly outperformed the MLP in test accuracy (73.91% vs 71.74%) and AUC (0.8438 vs 0.8210).",
        "Demonstrates the principle of parsimony: on small tabular clinical cohorts (~300 patients), linear and tree-based baselines perform exceptionally well.",
        "Deep neural models require thousands of training instances to realize their representational advantage over shallow models."
    )

    # -------------------------------------------------------------
    # 10.0 FEATURE IMPORTANCE ANALYSIS
    # -------------------------------------------------------------
    add_section("10.0 FEATURE IMPORTANCE & CLINICAL INTERPRETABILITY",
        "To interpret the decision boundaries of the neural network, Permutation Feature Importance was conducted on the held-out "
        "test set. Each feature column was randomly shuffled to disrupt its relationship with the target, and the resulting drop in ROC-AUC "
        "was recorded."
    )

    insert_figure(
        "eval_feature_importance.png", 15, "Top-10 Feature Importance (Permutation Drop in Test AUC)",
        "Horizontal bar chart displaying the top clinical features ranked by drop in ROC-AUC when permuted.",
        "The peak exercise ST slope (`slope`), thallium heart scan defect (`thal`), and major fluoroscopy vessels (`ca`) induced the greatest AUC drop.",
        "Aligns directly with clinical cardiology literature identifying abnormal myocardial repolarization and coronary calcification as dominant markers.",
        "Permutation importance evaluates predictive sensitivity rather than direct clinical causation; correlated features share importance."
    )

    # -------------------------------------------------------------
    # 11.0 LIMITATIONS & EDUCATIONAL DISCLAIMER
    # -------------------------------------------------------------
    add_section("11.0 LIMITATIONS AND EDUCATIONAL DISCLAIMER",
        "11.1 Dataset Limitations\n"
        "• Modest Sample Size: The deduplicated Cleveland cohort comprises 302 unique patients, which limits the capacity of deep networks.\n"
        "• Demographic Bias: The historical cohort over-represents middle-aged male patients, with limited ethnic and geographic diversity.\n"
        "• Hospitalized Referral Bias: Observations reflect symptomatic individuals referred for catheterization, not general screening.\n\n"
        "11.2 Model Limitations\n"
        "• Black-Box Properties: While permutation importance reveals key features, exact multi-layer non-linear pathways remain complex.\n"
        "• Sensitivity vs Specificity Trade-Off: In clinical cardiology, a recall (sensitivity) of 60.0% is insufficient for a standalone "
        "rule-out test, where missing a diseased patient carries severe morbidity risks.\n\n"
        "11.3 Educational Use Disclaimer\n"
        "THIS SOFTWARE, REPORT, AND SOURCE CODE ARE DEVELOPED EXCLUSIVELY FOR ACADEMIC AND EDUCATIONAL EVALUATION UNDER THE "
        "B.TECH ARTIFICIAL INTELLIGENCE AND DATA SCIENCE CURRICULUM. THE SYSTEM AND ITS PREDICTIONS MUST NOT BE USED, RELIED UPON, "
        "OR INTERPRETED AS A CLINICAL MEDICAL DIAGNOSIS, PROGNOSIS, OR TREATMENT PLAN. ALL REAL-WORLD MEDICAL DECISIONS MUST BE MADE "
        "BY LICENSED HEALTHCARE PROFESSIONALS UTILIZING STANDARD CLINICAL PROTOCOLS."
    )

    # -------------------------------------------------------------
    # 12.0 CONCLUSION & FUTURE SCOPE
    # -------------------------------------------------------------
    add_section("12.0 CONCLUSION AND FUTURE SCOPE",
        "12.1 Conclusion\n"
        "This project successfully developed an end-to-end academic study investigating heart disease diagnosis using exploratory data analysis, "
        "inferential statistics, and deep learning. By establishing the Seven Stages of Visualization, conducting rigorous deduplication, "
        "and expanding the feature space to 17 structured fields via evidence-based clinical derivation, we ensured complete academic integrity. "
        "Statistical testing uncovered pronounced physiological divergence in maximum heart rate and ST depression (p < 0.001). "
        "The trained Deep Learning MLP demonstrated robust discriminative performance (ROC-AUC = 0.8210, Precision = 83.33%, Specificity = 85.71%), "
        "while benchmarking reinforced the clinical reality that linear models remain highly competitive on small tabular medical datasets.\n\n"
        "12.2 Future Scope\n"
        "1. Integration with Massive Multi-Center Cohorts: Incorporating the UK Biobank and Framingham datasets to scale observations.\n"
        "2. Multi-Modal Fusion: Combining tabular electronic health records with raw 12-lead ECG time-series signals and cardiac MRI imaging.\n"
        "3. Advanced Explainability: Implementing Shapley Additive exPlanations (SHAP) and Integrated Gradients for local sample-level explanations.\n"
        "4. Clinically Calibrated Decision Thresholds: Optimizing classification cutoffs to maximize recall (sensitivity > 95%) for triage screening."
    )

    # -------------------------------------------------------------
    # 13.0 REFERENCES
    # -------------------------------------------------------------
    add_section("13.0 REFERENCES",
        "[1] R. Detrano, A. Janosi, W. Steinbrunn, M. Pfisterer, J. Schmid, S. Sandhu, K. Guppy, S. Lee, and V. Froelicher, "
        "\"International application of a new probability algorithm for the diagnosis of coronary artery disease,\" "
        "The American Journal of Cardiology, vol. 64, no. 5, pp. 304–310, 1989. DOI: 10.1016/0002-9149(89)90524-9.\n\n"
        "[2] H. Tanaka, K. D. Monahan, and D. R. Seals, \"Age-predicted maximal heart rate revisited,\" "
        "Journal of the American College of Cardiology, vol. 37, no. 1, pp. 153–156, 2001. DOI: 10.1016/S0735-1097(00)01054-8.\n\n"
        "[3] Y. LeCun, Y. Bengio, and G. Hinton, \"Deep learning,\" Nature, vol. 521, no. 7553, pp. 436–444, 2015. DOI: 10.1038/nature14539.\n\n"
        "[4] M. Fernández-Delgado, E. Cernadas, S. Barro, and D. Amorim, \"Do we need hundreds of classifiers to solve real world classification problems?\" "
        "Journal of Machine Learning Research, vol. 15, no. 1, pp. 3133–3181, 2014.\n\n"
        "[5] B. Shneiderman, \"The eyes have it: A task by data type taxonomy for information visualizations,\" "
        "in IEEE Symposium on Visual Languages, 1996, pp. 336–343. DOI: 10.1109/VL.1996.545307.\n\n"
        "[6] World Health Organization, \"Cardiovascular diseases (CVDs) key facts,\" WHO Fact Sheets, Geneva, Switzerland, 2023. "
        "[Online]. Available: https://www.who.int/news-room/fact-sheets/detail/cardiovascular-diseases-(cvds).\n\n"
        "[7] National Cholesterol Education Program (NCEP), \"Third Report of the National Cholesterol Education Program (NCEP) Expert Panel "
        "on Detection, Evaluation, and Treatment of High Blood Cholesterol in Adults (Adult Treatment Panel III),\" "
        "Circulation, vol. 106, no. 25, pp. 3143–3421, 2002."
    )

    # -------------------------------------------------------------
    # 14.0 APPENDIX
    # -------------------------------------------------------------
    add_section("14.0 APPENDIX: SOURCE CODE ARCHITECTURE & EXECUTION GUIDE",
        "14.1 Directory Structure\n"
        "The repository is organized following professional software engineering standards:\n"
        "heart-disease-eda-deep-learning/\n"
        "├── data/                       # Ingested dataset and documentation\n"
        "│   ├── heart.csv               # Verified clinical dataset\n"
        "│   └── README.md               # Dataset provenance and citation details\n"
        "├── notebooks/                  # Interactive experimentation environment\n"
        "│   └── Heart_Disease_EDA_Deep_Learning.ipynb # Complete execution workflow\n"
        "├── src/                        # Modular production Python code\n"
        "│   ├── data_preprocessing.py   # Ingestion, feature engineering, split\n"
        "│   ├── eda.py                  # Statistical testing and visualization\n"
        "│   ├── train_model.py          # MLP construction and hyperparameter search\n"
        "│   └── evaluate_model.py       # Metrics calculation and baseline comparison\n"
        "├── reports/                    # Complete academic deliverables\n"
        "│   ├── Project_Report.docx     # Editable academic report in Word format\n"
        "│   └── Project_Report.pdf      # Formatted academic publication PDF\n"
        "├── results/                    # High-resolution 300 DPI visualizations\n"
        "│   ├── 01_target_distribution.png ... 08_st_depression_slope_analysis.png\n"
        "│   └── eval_confusion_matrix.png ... eval_model_comparison.png\n"
        "├── models/                     # Serialized best trained neural model\n"
        "│   └── best_heart_disease_mlp.keras # Saved Keras model artifact\n"
        "├── README.md                   # Complete GitHub repository presentation\n"
        "├── requirements.txt            # Locked Python library dependencies\n"
        "└── .gitignore                  # Git tracking exclusion definitions\n\n"
        "14.2 Step-by-Step Reproduction Instructions\n"
        "1. Open terminal in the project directory:\n"
        "   cd \"CardioInsight AI\"\n"
        "2. Install required dependencies:\n"
        "   pip install -r requirements.txt\n"
        "3. Run data preprocessing and audit:\n"
        "   python src/data_preprocessing.py\n"
        "4. Run Exploratory Data Analysis to generate figures:\n"
        "   python src/eda.py\n"
        "5. Train the Deep Learning model and perform hyperparameter search:\n"
        "   python src/train_model.py\n"
        "6. Evaluate model performance and benchmark against baselines:\n"
        "   python src/evaluate_model.py"
    )

    docx_path = os.path.join(REPORTS_DIR, "Project_Report.docx")
    doc.save(docx_path)
    print(f"[SUCCESS] Academic Project_Report.docx successfully created at: {docx_path}")

# Numbered Canvas for PDF page numbering
class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super(NumberedCanvas, self).__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_number(num_pages)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def draw_page_number(self, page_count):
        if self._pageNumber > 1:
            self.saveState()
            self.setFont("Helvetica", 9)
            self.setFillColor(colors.HexColor("#555555"))
            page_text = f"Page {self._pageNumber} of {page_count}"
            self.drawRightString(612 - 54, 36, page_text)
            self.drawString(54, 36, "CardioInsight AI — KPR Institute of Engineering and Technology | Dept of AI & DS")
            self.setStrokeColor(colors.HexColor("#CCCCCC"))
            self.setLineWidth(0.5)
            self.line(54, 48, 612 - 54, 48)
            self.restoreState()

def create_pdf_report():
    print("[INFO] Generating academic Project_Report.pdf...")
    pdf_path = os.path.join(REPORTS_DIR, "Project_Report.pdf")
    doc = SimpleDocTemplate(
        pdf_path,
        pagesize=letter,
        leftMargin=54,
        rightMargin=54,
        topMargin=54,
        bottomMargin=54
    )

    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        textColor=colors.HexColor("#1A365D"),
        alignment=1,
        spaceAfter=15
    )
    subtitle_style = ParagraphStyle(
        'DocSub',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=11,
        leading=15,
        textColor=colors.HexColor("#333333"),
        alignment=1,
        spaceAfter=30
    )
    h1_style = ParagraphStyle(
        'H1',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=13,
        leading=16,
        textColor=colors.HexColor("#2B5C8F"),
        spaceBefore=14,
        spaceAfter=6,
        keepWithNext=True
    )
    body_style = ParagraphStyle(
        'Body',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9.5,
        leading=13.5,
        textColor=colors.HexColor("#222222"),
        spaceAfter=6
    )
    caption_style = ParagraphStyle(
        'Caption',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8.5,
        leading=11,
        textColor=colors.HexColor("#1A365D"),
        alignment=1,
        spaceBefore=4,
        spaceAfter=8
    )

    story = []

    # Title Page
    story.append(Spacer(1, 40))
    story.append(Paragraph("KPR INSTITUTE OF ENGINEERING AND TECHNOLOGY", ParagraphStyle('InstMain', parent=title_style, fontSize=14, leading=17, textColor=colors.HexColor("#1A365D"))))
    story.append(Paragraph("DEPARTMENT OF ARTIFICIAL INTELLIGENCE AND DATA SCIENCE", ParagraphStyle('Inst', parent=title_style, fontSize=11, leading=14, textColor=colors.HexColor("#2B5C8F"))))
    story.append(Paragraph("ACADEMIC CAPSTONE PROJECT REPORT — 2026", ParagraphStyle('InstSub', parent=subtitle_style, fontSize=10, leading=13, spaceAfter=25)))
    story.append(Spacer(1, 15))
    story.append(Paragraph("EXPLORATORY DATA ANALYSIS AND VISUALIZATION OF HEART DISEASE USING STATISTICAL ANALYSIS AND DEEP LEARNING", title_style))
    story.append(Paragraph("A Capstone Project Submitted in Partial Fulfillment of the Requirements for the Degree of<br/>Bachelor of Technology in Artificial Intelligence and Data Science", subtitle_style))
    story.append(Spacer(1, 30))

    meta_text = (
        "<b>Submitted By:</b><br/>"
        "STUDENT NAME: <b>ROSHAN VIKRAM A V</b><br/>"
        "ROLL NUMBER: <b>25ADL09</b><br/>"
        "DEPARTMENT: Department of Artificial Intelligence and Data Science<br/><br/>"
        "<b>Academic Evaluation:</b><br/>"
        "PROGRAM: B.Tech (Artificial Intelligence & Data Science)<br/>"
        "INSTITUTION: <b>KPR Institute of Engineering and Technology</b><br/>"
        "ACADEMIC YEAR: 2025–2026<br/>"
        "SUBMISSION DATE: <b>15.10.2026 (15th October 2026)</b>"
    )
    story.append(Paragraph(meta_text, ParagraphStyle('Meta', parent=body_style, alignment=1, fontSize=10, leading=15)))
    story.append(PageBreak())

    # Abstract
    story.append(Paragraph("ABSTRACT", h1_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#2B5C8F"), spaceAfter=10))
    abs_p = (
        "Cardiovascular diseases (CVDs) constitute the leading global cause of death, accounting for approximately "
        "17.9 million fatalities each year. Non-invasive, machine-learning-assisted diagnostic triaging offers substantial "
        "clinical promise for early intervention. This academic study presents an end-to-end data science and deep learning "
        "investigation of heart disease using the landmark UCI Heart Disease dataset. Guided by the Seven Stages of Visualization "
        "methodology, the raw cohort of 1,025 instances was audited, deduplicated (isolating 302 unique patients to eliminate data leakage), "
        "and augmented with clinically validated derived features (AHA blood pressure classifications, NCEP ATP III cholesterol staging, "
        "and % of age-predicted maximum heart rate reserve), expanding the analytical space to 17 fields. "
        "Inferential statistical tests identified significant divergence in maximum heart rate (t = -14.86, p < 0.001) and exercise ST depression "
        "(t = 15.41, p < 0.001). A Deep Multilayer Perceptron (MLP) was constructed in TensorFlow/Keras, optimized across five hyperparameter "
        "configurations, and evaluated on a held-out test cohort (15%). The optimal MLP achieved 71.74% accuracy, 83.33% precision, 85.71% specificity, "
        "and an ROC-AUC of 0.8210, benchmarked against Logistic Regression and Random Forest models. Permutation importance confirmed peak exercise "
        "ST slope and fluoroscopy vessel counts as leading predictive features."
    )
    story.append(Paragraph(abs_p, body_style))
    story.append(Spacer(1, 10))
    story.append(Paragraph("<b>Keywords:</b> Heart Disease, Exploratory Data Analysis, Deep Learning, Multilayer Perceptron, Medical Informatics, Seven Stages of Visualization.", body_style))
    story.append(PageBreak())

    # Helper for adding sections in PDF
    def add_pdf_section(title, content):
        story.append(Paragraph(title, h1_style))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2B5C8F"), spaceAfter=8))
        story.append(Paragraph(content, body_style))
        story.append(Spacer(1, 10))

    # 1.0 Introduction
    add_pdf_section("1.0 INTRODUCTION & PROJECT OBJECTIVES",
        "<b>1.1 Background:</b> Cardiovascular diseases comprise disorders of the heart and blood vessels, including coronary artery disease. "
        "According to the WHO, over four out of five CVD deaths are due to heart attacks and strokes. Early detection enables preventive interventions.<br/><br/>"
        "<b>1.2 Problem Statement:</b> Contemporary academic machine learning studies frequently suffer from split contamination (data leakage "
        "on resampled duplicates) and insufficient statistical validation. This project delivers a transparent, mathematically sound exploratory analysis "
        "and deep learning classification framework adhering to the Seven Stages of Visualization.<br/><br/>"
        "<b>1.3 Objectives:</b> (1) Ingest, audit, and clean the UCI Heart Disease cohort, expanding features to 17 fields; (2) Execute univariate, "
        "bivariate, and multivariate statistical testing; (3) Produce publication-quality clinical visualizations; (4) Train and tune a regularized "
        "MLP classifier in TensorFlow/Keras; (5) Benchmark against linear and ensemble baselines; and (6) Provide feature importance interpretations.<br/><br/>"
        "<b>1.4 Scope:</b> Prepared strictly for academic educational evaluation in the B.Tech Artificial Intelligence & Data Science curriculum."
    )

    # 2.0 Literature Review
    add_pdf_section("2.0 LITERATURE REVIEW",
        "<b>Clinical Diagnostics:</b> Detrano et al. (1989) introduced the Cleveland Heart Disease dataset, establishing that exercise thallium scintigraphy "
        "and fluoroscopy exhibit superior discriminatory power over resting ECG. Tanaka, Monahan, and Seals (2001) validated the age-predicted maximal "
        "heart rate formula across 18,712 subjects, establishing heart rate reserve as a critical marker of chronotropic incompetence.<br/><br/>"
        "<b>Machine Learning Benchmarks:</b> LeCun, Bengio, and Hinton (2015) outlined deep learning principles, noting that tabular clinical datasets "
        "require strong regularization (Dropout, L2 decay, Batch Normalization) to prevent catastrophic overfitting. Fernández-Delgado et al. (2014) "
        "demonstrated across 179 classifiers that shallow linear and ensemble models frequently match or exceed deep architectures on small tabular datasets.<br/><br/>"
        "<b>Visualization Frameworks:</b> Shneiderman (1996) and Colin Ware (2012) formalized structured visual information exploration, inspiring our "
        "Seven Stages of Visualization."
    )

    # 3.0 Dataset Description
    add_pdf_section("3.0 DATASET DESCRIPTION & CLINICAL PREPROCESSING",
        "<b>Dataset Provenance:</b> The dataset originates from the landmark UCI Machine Learning Repository (Cleveland Clinic Foundation). "
        "The raw dataset in `data/heart.csv` contains 1,025 instances.<br/><br/>"
        "<b>Clinical Feature Engineering (17 Structured Fields):</b> To satisfy the academic requirement of ≥ 15 fields without synthetic fabrication, "
        "we derived three evidence-based medical features:<br/>"
        "• <i>max_hr_pct</i>: Percentage of age-predicted maximum heart rate: thalach / (220 - age) * 100.<br/>"
        "• <i>bp_category</i>: AHA Blood Pressure Staging (0: Normal, 1: Elevated, 2: Stage 1 HTN, 3: Stage 2 HTN).<br/>"
        "• <i>chol_category</i>: NCEP ATP III Cholesterol Risk Category (0: Desirable, 1: Borderline High, 2: High).<br/><br/>"
        "<b>Deduplication & Leakage Prevention:</b> The 1,025 raw rows contain 723 duplicates resulting from bootstrap resampling. "
        "Deduplication isolated 302 unique patients. Stratified splitting partitioned the data into 70% Train (211), 15% Val (45), and 15% Test (46). "
        "StandardScaler was fitted strictly on training data."
    )

    # 4.0 Seven Stages of Visualization
    add_pdf_section("4.0 THE SEVEN STAGES OF VISUALIZATION",
        "The project rigorously applies the Seven Stages of Visualization workflow (Fry, 2004; Ware, 2012):<br/>"
        "<b>1. Acquire:</b> Ingestion of genuine patient records from verified local repository storage.<br/>"
        "<b>2. Parse:</b> Column identification, structural decoding, missingness verification (0 missing values).<br/>"
        "<b>3. Filter:</b> Deduplication of 723 records; IQR-based outlier threshold calculations.<br/>"
        "<b>4. Mine:</b> Extraction of descriptive statistics, t-tests, Chi-square tests, and feature derivations.<br/>"
        "<b>5. Represent:</b> Selection of boxplots with strip jitter, correlation heatmaps, violin plots, and ROC curves.<br/>"
        "<b>6. Refine:</b> Professional aesthetics (#2B5C8F and #D9534F palettes), crisp labels, and 300 DPI rendering.<br/>"
        "<b>7. Interact & Communicate:</b> Synthesis of clinical interpretations and diagnostic limitations."
    )

    # 5.0 EDA & Statistical Findings
    add_pdf_section("5.0 EXPLORATORY DATA ANALYSIS & INFERENTIAL STATISTICS",
        "<b>Univariate Statistics:</b> Mean age = 54.43 ± 9.07 yrs; Resting BP = 131.61 ± 17.52 mmHg; Cholesterol = 246.00 ± 51.59 mg/dL; "
        "Max Heart Rate = 149.11 ± 23.01 bpm; ST Depression = 1.07 ± 1.18 mm.<br/><br/>"
        "<b>Inferential Hypothesis Testing:</b> Significant pathological differences were established across target classes:<br/>"
        "• <i>Max Heart Rate (thalach)</i>: t = -14.862, p = 3.42e-45 (Significant)<br/>"
        "• <i>ST Depression (oldpeak)</i>: t = 15.409, p = 3.87e-47 (Significant)<br/>"
        "• <i>Age</i>: t = 7.574, p = 8.18e-14 (Significant)<br/>"
        "• <i>Chest Pain Type (cp)</i>: Chi-Square = 280.98, p = 1.30e-60 (Significant)<br/>"
        "• <i>Thalassemia (thal)</i>: Chi-Square = 280.33, p = 1.80e-60 (Significant)<br/>"
        "• <i>Fasting Blood Sugar (fbs)</i>: Chi-Square = 1.513, p = 0.2186 (Not statistically significant at α = 0.05)."
    )

    # 6.0 Visualizations in PDF
    story.append(Paragraph("6.0 CLINICAL VISUALIZATION GALLERY", h1_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2B5C8F"), spaceAfter=10))

    def add_pdf_fig(img_name, fig_num, title, text):
        img_p = os.path.join(RESULTS_DIR, img_name)
        if os.path.exists(img_p):
            story.append(RLImage(img_p, width=420, height=240))
            story.append(Paragraph(f"Figure {fig_num}: {title}", caption_style))
            story.append(Paragraph(text, body_style))
            story.append(Spacer(1, 10))

    add_pdf_fig("01_target_distribution.png", 1, "Target Class Distribution",
        "Balanced representation (51.3% disease vs 48.7% normal) confirming no class imbalance bias.")
    add_pdf_fig("02_age_distribution.png", 2, "Age Distribution Stratified by Disease Status",
        "Elevated disease density observed between 50 and 62 years of age.")
    add_pdf_fig("03_correlation_heatmap.png", 3, "Pearson Correlation Matrix Heatmap",
        "Strong linear correlation between target and thalach (+0.42) and oldpeak (-0.44).")
    add_pdf_fig("04_thalach_boxplot.png", 4, "Maximum Heart Rate Achieved (thalach) by Class",
        "Median maximum heart rate is significantly higher in diseased subjects (161 bpm vs 142 bpm; p < 0.001).")
    add_pdf_fig("05_age_vs_thalach_scatter.png", 5, "Age vs Maximum Heart Rate with Regression Trends",
        "Demonstrates age-dependent decline in cardiac reserve while maintaining distinct group intercepts.")
    add_pdf_fig("06_pairplot_selected_features.png", 6, "Pairwise Interactions of Key Cardiovascular Metrics",
        "Multi-dimensional diagnostic separation justifying non-linear neural network classifiers.")

    # 7.0 & 8.0 Model Architecture & Tuning
    add_pdf_section("7.0 & 8.0 DEEP LEARNING MODEL & HYPERPARAMETER EXPERIMENTS",
        "<b>Model Design:</b> Implemented in TensorFlow/Keras with an input dimension of 16 features. "
        "Hidden Layer 1 (64 units, ReLU, He normal, L2 reg = 0.001) → Batch Normalization → Dropout (0.2) → "
        "Hidden Layer 2 (32 units, ReLU, L2 reg = 0.001) → Dropout (0.1) → Hidden Layer 3 (16 units, ReLU) → "
        "Output Layer (1 unit, Sigmoid). Optimized via Adam (LR = 0.001) with Binary Cross-Entropy loss.<br/><br/>"
        "<b>Hyperparameter Validation:</b> Five configurations were benchmarked on the 15% validation cohort. "
        "Experiment 4 (Batch Size = 32, LR = 0.001) attained the lowest validation loss (0.5009) and highest Validation AUC (0.9276), "
        "and was selected for final test set deployment."
    )

    # 9.0 Results & Evaluation Plots
    story.append(Paragraph("9.0 RESULTS AND BENCHMARK DISCUSSION", h1_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2B5C8F"), spaceAfter=10))

    add_pdf_fig("eval_training_validation_loss.png", 7, "Training and Validation Loss Over Epochs",
        "Validation loss reached its global optimum (0.5009) near epoch 32, with early stopping restoring best weights.")
    add_pdf_fig("eval_confusion_matrix.png", 8, "Held-Out Test Set Confusion Matrix (MLP)",
        "On 46 held-out test patients: 18 True Negatives, 15 True Positives, 3 False Positives, and 10 False Negatives. "
        "Achieves 83.33% Precision and 85.71% Specificity.")
    add_pdf_fig("eval_roc_curve.png", 9, "Receiver Operating Characteristic (ROC) Comparison",
        "ROC Curves comparing MLP (AUC = 0.8210) against Logistic Regression (AUC = 0.8438) and Random Forest (AUC = 0.8305).")
    add_pdf_fig("eval_model_comparison.png", 10, "Model Comparison Across Five Key Metrics",
        "Demonstrates the principle of parsimony: linear models remain competitive on small tabular biomedical cohorts.")

    # 10.0 Feature Importance
    add_pdf_fig("eval_feature_importance.png", 11, "Top-10 Permutation Feature Importance",
        "Peak exercise ST slope, thallium defects, and fluoroscopy vessel counts identified as primary predictive drivers.")

    # 11.0, 12.0, 13.0 Summary, Limitations, References
    add_pdf_section("11.0 & 12.0 LIMITATIONS, CONCLUSION & FUTURE SCOPE",
        "<b>Limitations:</b> (1) Modest cohort size (302 unique patients); (2) Sensitivity of 60.0% is insufficient for sole clinical triage; "
        "(3) Tabular demographic bias toward male hospital referrals.<br/><br/>"
        "<b>Educational Disclaimer:</b> DEVELOPED STRICTLY FOR EDUCATIONAL EVALUATION UNDER THE B.TECH ARTIFICIAL INTELLIGENCE "
        "AND DATA SCIENCE CURRICULUM. PREDICTIONS MUST NOT BE APPLIED OR RELIED UPON AS MEDICAL DIAGNOSES.<br/><br/>"
        "<b>Conclusion:</b> This capstone study completed an academically rigorous investigation of cardiovascular disease, successfully "
        "coupling the Seven Stages of Visualization with deep learning classification (ROC-AUC = 0.8210). Future work includes multi-modal "
        "fusion with raw ECG waveforms and external validation on large-scale hospital cohorts."
    )

    add_pdf_section("13.0 ACADEMIC REFERENCES (IEEE STYLE)",
        "[1] R. Detrano et al., 'International application of a new probability algorithm for the diagnosis of coronary artery disease,' "
        "Am. J. Cardiol., vol. 64, no. 5, pp. 304–310, 1989.<br/>"
        "[2] H. Tanaka et al., 'Age-predicted maximal heart rate revisited,' J. Am. Coll. Cardiol., vol. 37, no. 1, pp. 153–156, 2001.<br/>"
        "[3] Y. LeCun, Y. Bengio, and G. Hinton, 'Deep learning,' Nature, vol. 521, no. 7553, pp. 436–444, 2015.<br/>"
        "[4] M. Fernández-Delgado et al., 'Do we need hundreds of classifiers to solve real world classification problems?' JMLR, vol. 15, pp. 3133–3181, 2014.<br/>"
        "[5] B. Shneiderman, 'The eyes have it: A task by data type taxonomy for information visualizations,' in IEEE VL, 1996, pp. 336–343.<br/>"
        "[6] World Health Organization, 'Cardiovascular diseases (CVDs) key facts,' WHO Fact Sheets, Geneva, Switzerland, 2023."
    )

    doc.build(story, canvasmaker=NumberedCanvas)
    print(f"[SUCCESS] Academic Project_Report.pdf successfully created at: {pdf_path}")

if __name__ == "__main__":
    create_docx_report()
    create_pdf_report()
