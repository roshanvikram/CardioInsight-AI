"""
CardioInsight AI - Master Pipeline Orchestrator
Author: Senior Data Scientist / ML Engineer
Description: Executes the complete end-to-end data science and deep learning workflow:
             1. Data Ingestion, Clinical Feature Engineering & Preprocessing
             2. Exploratory Data Analysis & Inferential Statistical Testing
             3. Deep Learning MLP Training & Hyperparameter Tuning
             4. Test Evaluation, Baseline Benchmarking & Permutation Importance
             5. Publication Academic Report Generation (Word DOCX & PDF)
"""

import sys
import os
import time

def print_banner(step_num, title):
    border = "=" * 70
    print(f"\n{border}")
    print(f" STEP {step_num}: {title.upper()}")
    print(f"{border}\n")

def run_step(description, command):
    print(f">> Starting: {description}...")
    start_time = time.time()
    exit_code = os.system(command)
    elapsed = time.time() - start_time
    if exit_code != 0:
        print(f"\n[ERROR] Command failed with exit code {exit_code}: {command}")
        sys.exit(exit_code)
    print(f">> [DONE] Completed in {elapsed:.2f} seconds.\n")

def main():
    print("=" * 70)
    print("       CARDIOINSIGHT AI: END-TO-END EXECUTION PIPELINE")
    print(" Exploratory Data Analysis & Deep Learning for Heart Disease")
    print("=" * 70)

    # Step 1: Preprocessing & Leakage Prevention
    print_banner(1, "Data Ingestion & Clinical Feature Engineering")
    run_step("Data Ingestion, Clinical Derivation & Leak-Free Splitting", f"{sys.executable} src/data_preprocessing.py")

    # Step 2: Exploratory Data Analysis
    print_banner(2, "Exploratory Data Analysis & Statistical Testing")
    run_step("Univariate, Bivariate, Multivariate EDA & 300 DPI Visualizations", f"{sys.executable} src/eda.py")

    # Step 3: Deep Learning Training & Tuning
    print_banner(3, "Deep Learning MLP Training & Hyperparameter Search")
    run_step("TensorFlow/Keras Model Training & Validation Tuning", f"{sys.executable} src/train_model.py")

    # Step 4: Model Evaluation & Benchmarking
    print_banner(4, "Model Evaluation & Baseline Benchmarking")
    run_step("Test Set Metrics, Confusion Matrix & Feature Importance", f"{sys.executable} src/evaluate_model.py")

    # Step 5: Academic Report Generation
    print_banner(5, "Academic Report Generation (DOCX & PDF)")
    run_step("Building Academic Word (DOCX) and Publication (PDF) Reports", f"{sys.executable} generate_reports.py")

    print("\n" + "=" * 70)
    print(" [SUCCESS] ALL 5 PIPELINE STAGES COMPLETED SUCCESSFULLY!")
    print("=" * 70)
    print("Artifact Summary:")
    print(" • Visualizations: 15 High-Resolution PNG charts in results/")
    print(" • Trained Model: models/best_heart_disease_mlp.keras")
    print(" • Editable Word Report: reports/Project_Report.docx")
    print(" • Publication PDF Report: reports/Project_Report.pdf")
    print(" • Interactive Notebook: notebooks/Heart_Disease_EDA_Deep_Learning.ipynb")
    print("=" * 70 + "\n")

if __name__ == "__main__":
    main()
