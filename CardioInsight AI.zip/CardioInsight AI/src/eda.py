"""
CardioInsight AI - Exploratory Data Analysis (EDA) Module
Author: Senior Data Scientist / ML Engineer
Description: Executes comprehensive univariate, bivariate, multivariate, and distribution
             analysis with formal statistical hypothesis testing (t-tests, Chi-square).
             Implements the Seven Stages of Visualization and generates publication-quality
             high-resolution figures saved in results/.
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

from data_preprocessing import load_dataset, engineer_clinical_features

# Set publication style
plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
plt.rcParams['font.sans-serif'] = 'Arial'
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 11

RESULTS_DIR = "results"
os.makedirs(RESULTS_DIR, exist_ok=True)

def compute_univariate_stats(df, numerical_cols):
    """
    Computes rigorous univariate statistical metrics:
    Mean, Median, Mode, Variance, Std Dev, Min, Max, Q1, Q3, IQR, Skewness.
    """
    stats_list = []
    for col in numerical_cols:
        series = df[col]
        mode_val = series.mode().iloc[0] if not series.mode().empty else np.nan
        q1 = series.quantile(0.25)
        q3 = series.quantile(0.75)
        stats_list.append({
            "Feature": col,
            "Mean": round(float(series.mean()), 2),
            "Median": round(float(series.median()), 2),
            "Mode": round(float(mode_val), 2),
            "Variance": round(float(series.var()), 2),
            "Std Dev": round(float(series.std()), 2),
            "Min": round(float(series.min()), 2),
            "Q1 (25%)": round(float(q1), 2),
            "Q3 (75%)": round(float(q3), 2),
            "IQR": round(float(q3 - q1), 2),
            "Max": round(float(series.max()), 2),
            "Skewness": round(float(series.skew()), 3)
        })
    return pd.DataFrame(stats_list)

def compute_bivariate_stats(df, numerical_cols, categorical_cols, target_col='target'):
    """
    Executes formal statistical hypothesis testing:
    - Numerical features: Two-sample independent t-test and Mann-Whitney U test across target classes.
    - Categorical features: Pearson's Chi-Square Test of Independence with target.
    """
    num_tests = []
    g0 = df[df[target_col] == 0]
    g1 = df[df[target_col] == 1]
    
    for col in numerical_cols:
        val0 = g0[col].dropna()
        val1 = g1[col].dropna()
        t_stat, p_val_t = stats.ttest_ind(val0, val1, equal_var=False)
        u_stat, p_val_u = stats.mannwhitneyu(val0, val1, alternative='two-sided')
        num_tests.append({
            "Feature": col,
            "Mean (No Disease)": round(float(val0.mean()), 2),
            "Mean (Disease)": round(float(val1.mean()), 2),
            "t-statistic": round(float(t_stat), 3),
            "t-test p-value": f"{p_val_t:.4e}",
            "Mann-Whitney U p-val": f"{p_val_u:.4e}",
            "Statistically Significant (p<0.05)": "Yes" if p_val_t < 0.05 else "No"
        })
    df_num_tests = pd.DataFrame(num_tests)
    
    cat_tests = []
    for col in categorical_cols:
        contingency = pd.crosstab(df[col], df[target_col])
        chi2, p_val, dof, _ = stats.chi2_contingency(contingency)
        cat_tests.append({
            "Feature": col,
            "Chi-Square Stat": round(float(chi2), 3),
            "Degrees of Freedom": dof,
            "p-value": f"{p_val:.4e}",
            "Statistically Significant (p<0.05)": "Yes" if p_val < 0.05 else "No"
        })
    df_cat_tests = pd.DataFrame(cat_tests)
    
    return df_num_tests, df_cat_tests

def generate_eda_visualizations(df):
    """
    Generates and saves the required EDA visualizations in high-resolution PNG format.
    Every chart includes title, axis labels, custom palettes, annotations, and legends.
    """
    print("[INFO] Generating EDA Visualizations...")
    
    # -------------------------------------------------------------
    # Visualization 1: Target Class Distribution Count Plot
    # -------------------------------------------------------------
    plt.figure(figsize=(7, 5))
    palette = ["#2b5c8f", "#d9534f"]
    ax = sns.countplot(data=df, x='target', palette=palette, hue='target', legend=False)
    plt.title("Target Class Distribution (Heart Disease Prevalence)", fontsize=14, weight='bold', pad=15)
    plt.xlabel("Heart Disease Status (0 = Absence, 1 = Presence)", fontsize=12)
    plt.ylabel("Patient Count", fontsize=12)
    plt.xticks([0, 1], ["Absence (<50% stenosis)", "Presence (>50% stenosis)"])
    
    total = len(df)
    for p in ax.patches:
        height = p.get_height()
        percentage = (height / total) * 100
        ax.annotate(f"{int(height)}\n({percentage:.1f}%)",
                    (p.get_x() + p.get_width() / 2., height / 2),
                    ha='center', va='center', fontsize=11, color='white', weight='bold')
    
    plt.tight_layout()
    plot1_path = os.path.join(RESULTS_DIR, "01_target_distribution.png")
    plt.savefig(plot1_path, dpi=300)
    plt.close()
    print(f"  [+] Saved: {plot1_path}")

    # -------------------------------------------------------------
    # Visualization 2: Age Distribution Histogram with KDE Density Curve
    # -------------------------------------------------------------
    plt.figure(figsize=(8, 5))
    sns.histplot(data=df, x='age', hue='target', kde=True, bins=20,
                 palette=["#2b5c8f", "#d9534f"], element="step", alpha=0.4)
    plt.title("Age Distribution Stratified by Heart Disease Status", fontsize=14, weight='bold', pad=15)
    plt.xlabel("Age (Years)", fontsize=12)
    plt.ylabel("Patient Frequency", fontsize=12)
    plt.legend(title="Heart Disease", labels=["Presence (1)", "Absence (0)"])
    plt.axvline(df['age'].mean(), color='black', linestyle='--', linewidth=1.5,
                label=f"Mean Age: {df['age'].mean():.1f} yrs")
    
    plt.tight_layout()
    plot2_path = os.path.join(RESULTS_DIR, "02_age_distribution.png")
    plt.savefig(plot2_path, dpi=300)
    plt.close()
    print(f"  [+] Saved: {plot2_path}")

    # -------------------------------------------------------------
    # Visualization 3: Numerical Feature Correlation Heatmap
    # -------------------------------------------------------------
    plt.figure(figsize=(11, 9))
    corr_cols = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak', 'max_hr_pct', 'target']
    corr_matrix = df[corr_cols].corr()
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
    cmap = sns.diverging_palette(230, 20, as_cmap=True)
    
    sns.heatmap(corr_matrix, mask=mask, cmap=cmap, vmin=-1.0, vmax=1.0,
                annot=True, fmt=".2f", square=True, linewidths=.8, cbar_kws={"shrink": .8})
    plt.title("Pearson Correlation Heatmap of Key Cardiac Measurements", fontsize=14, weight='bold', pad=15)
    plt.tight_layout()
    plot3_path = os.path.join(RESULTS_DIR, "03_correlation_heatmap.png")
    plt.savefig(plot3_path, dpi=300)
    plt.close()
    print(f"  [+] Saved: {plot3_path}")

    # -------------------------------------------------------------
    # Visualization 4: Boxplot of Maximum Heart Rate Across Target Classes
    # -------------------------------------------------------------
    plt.figure(figsize=(8, 5.5))
    sns.boxplot(data=df, x='target', y='thalach', palette=["#4a90e2", "#e74c3c"],
                width=0.45, boxprops=dict(alpha=0.8), hue='target', legend=False)
    sns.stripplot(data=df, x='target', y='thalach', color='black', alpha=0.3, jitter=0.2, size=5)
    plt.title("Maximum Heart Rate Achieved (thalach) by Disease Status", fontsize=14, weight='bold', pad=15)
    plt.xlabel("Heart Disease Status", fontsize=12)
    plt.ylabel("Maximum Heart Rate (bpm)", fontsize=12)
    plt.xticks([0, 1], ["Absence (Normal)", "Presence (Heart Disease)"])
    
    # Calculate medians for annotation
    med0 = df[df['target'] == 0]['thalach'].median()
    med1 = df[df['target'] == 1]['thalach'].median()
    plt.text(0, med0 + 3, f"Median: {med0:.0f} bpm", horizontalalignment='center', weight='bold', color='#1a365d')
    plt.text(1, med1 + 3, f"Median: {med1:.0f} bpm", horizontalalignment='center', weight='bold', color='#781e1e')
    
    plt.tight_layout()
    plot4_path = os.path.join(RESULTS_DIR, "04_thalach_boxplot.png")
    plt.savefig(plot4_path, dpi=300)
    plt.close()
    print(f"  [+] Saved: {plot4_path}")

    # -------------------------------------------------------------
    # Visualization 5: Scatterplot: Age vs Maximum Heart Rate with Regression Trendlines
    # -------------------------------------------------------------
    plt.figure(figsize=(8.5, 6))
    palette_dict = {0: "#2b5c8f", 1: "#d9534f"}
    sns.scatterplot(data=df, x='age', y='thalach', hue='target', palette=palette_dict,
                    alpha=0.65, s=60, edgecolor='w')
    sns.regplot(data=df[df['target'] == 0], x='age', y='thalach', scatter=False,
                color='#2b5c8f', label='Trend: Absence (0)', line_kws={"linewidth": 2})
    sns.regplot(data=df[df['target'] == 1], x='age', y='thalach', scatter=False,
                color='#d9534f', label='Trend: Presence (1)', line_kws={"linewidth": 2})
    
    plt.title("Age vs. Maximum Heart Rate (thalach) with Stratified Trendlines", fontsize=14, weight='bold', pad=15)
    plt.xlabel("Age (Years)", fontsize=12)
    plt.ylabel("Maximum Heart Rate Achieved (bpm)", fontsize=12)
    plt.legend(title="Heart Disease Status", labels=["Absence (0)", "Presence (1)"])
    plt.tight_layout()
    plot5_path = os.path.join(RESULTS_DIR, "05_age_vs_thalach_scatter.png")
    plt.savefig(plot5_path, dpi=300)
    plt.close()
    print(f"  [+] Saved: {plot5_path}")

    # -------------------------------------------------------------
    # Visualization 6: Pairplot of Selected Numerical Medical Features
    # -------------------------------------------------------------
    pair_features = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak', 'target']
    pairplot = sns.pairplot(df[pair_features], hue='target', palette=["#2b5c8f", "#d9534f"],
                            diag_kind='kde', plot_kws={'alpha': 0.6, 's': 30},
                            corner=True)
    pairplot.fig.suptitle("Pairwise Relationships of Key Cardiovascular Attributes", y=1.02, fontsize=15, weight='bold')
    plot6_path = os.path.join(RESULTS_DIR, "06_pairplot_selected_features.png")
    pairplot.savefig(plot6_path, dpi=300)
    plt.close()
    print(f"  [+] Saved: {plot6_path}")

    # -------------------------------------------------------------
    # Bonus Visualization 7: Chest Pain Type vs Heart Disease Prevalence
    # -------------------------------------------------------------
    plt.figure(figsize=(8, 5))
    cp_df = pd.crosstab(df['cp'], df['target'], normalize='index') * 100
    ax = cp_df.plot(kind='bar', stacked=True, color=["#2b5c8f", "#d9534f"], figsize=(8, 5), edgecolor='black')
    plt.title("Heart Disease Prevalence Across Chest Pain Types (cp)", fontsize=14, weight='bold', pad=15)
    plt.xlabel("Chest Pain Type", fontsize=12)
    plt.ylabel("Proportion (%)", fontsize=12)
    plt.xticks([0, 1, 2, 3], ["0: Typical Angina", "1: Atypical Angina", "2: Non-anginal", "3: Asymptomatic"], rotation=15)
    plt.legend(title="Heart Disease", labels=["Absence (0)", "Presence (1)"], bbox_to_anchor=(1.02, 1), loc='upper left')
    plt.tight_layout()
    plot7_path = os.path.join(RESULTS_DIR, "07_chest_pain_analysis.png")
    plt.savefig(plot7_path, dpi=300)
    plt.close()
    print(f"  [+] Saved: {plot7_path}")

    # -------------------------------------------------------------
    # Bonus Visualization 8: ST Depression (oldpeak) by Exercise ST Slope
    # -------------------------------------------------------------
    plt.figure(figsize=(8, 5.5))
    sns.violinplot(data=df, x='slope', y='oldpeak', hue='target', split=True,
                   palette=["#4a90e2", "#e74c3c"], inner="quart")
    plt.title("ST Depression (oldpeak) Distribution by Peak Exercise ST Slope", fontsize=14, weight='bold', pad=15)
    plt.xlabel("Peak Exercise ST Segment Slope", fontsize=12)
    plt.ylabel("ST Depression Induced by Exercise (oldpeak, mm)", fontsize=12)
    plt.xticks([0, 1, 2], ["0: Upsloping", "1: Flat", "2: Downsloping"])
    plt.legend(title="Heart Disease", labels=["Absence (0)", "Presence (1)"])
    plt.tight_layout()
    plot8_path = os.path.join(RESULTS_DIR, "08_st_depression_slope_analysis.png")
    plt.savefig(plot8_path, dpi=300)
    plt.close()
    print(f"  [+] Saved: {plot8_path}")

    print("[SUCCESS] All 8 EDA figures generated and saved.")

if __name__ == "__main__":
    df = load_dataset()
    df_feat = engineer_clinical_features(df)
    
    num_cols = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak', 'max_hr_pct']
    cat_cols = ['sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'ca', 'thal', 'bp_category', 'chol_category']
    
    print("\n--- UNIVARIATE STATISTICAL SUMMARY ---")
    univ_summary = compute_univariate_stats(df_feat, num_cols)
    print(univ_summary.to_string(index=False))
    
    print("\n--- BIVARIATE HYPOTHESIS TESTING (NUMERICAL) ---")
    num_tests, cat_tests = compute_bivariate_stats(df_feat, num_cols, cat_cols)
    print(num_tests.to_string(index=False))
    
    print("\n--- BIVARIATE HYPOTHESIS TESTING (CATEGORICAL CHI-SQUARE) ---")
    print(cat_tests.to_string(index=False))
    
    generate_eda_visualizations(df_feat)
