"""
CardioInsight AI - Model Evaluation, Baseline Comparison & Interpretability Module
Author: Senior Data Scientist / ML Engineer
Description: Evaluates the trained Deep Learning MLP against held-out test data (15%).
             Benchmarks against Logistic Regression and Random Forest baselines.
             Computes permutation feature importance.
             Generates publication-ready evaluation charts saved in results/.
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow as tf
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, roc_curve, precision_recall_curve,
    classification_report, average_precision_score
)
from sklearn.inspection import permutation_importance

from data_preprocessing import load_dataset, engineer_clinical_features, split_and_preprocess

RESULTS_DIR = "results"
MODELS_DIR = "models"
os.makedirs(RESULTS_DIR, exist_ok=True)

# Styling configuration
plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
plt.rcParams['font.sans-serif'] = 'Arial'
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300

def load_trained_mlp(model_path="models/best_heart_disease_mlp.keras"):
    """Loads the serialized Keras MLP model."""
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found at {model_path}. Train the model first.")
    return tf.keras.models.load_model(model_path)

def evaluate_classifier(y_true, y_pred, y_prob):
    """Computes comprehensive classification metrics."""
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    auc = roc_auc_score(y_true, y_prob)
    
    # Specificity = TN / (TN + FP)
    cm = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm.ravel()
    spec = tn / (tn + fp) if (tn + fp) > 0 else 0
    
    return {
        "Accuracy": round(acc, 4),
        "Precision": round(prec, 4),
        "Recall (Sensitivity)": round(rec, 4),
        "Specificity": round(spec, 4),
        "F1-Score": round(f1, 4),
        "ROC-AUC": round(auc, 4),
        "Confusion_Matrix": cm
    }

def train_baselines(X_train, y_train, X_test, y_test):
    """
    Trains standard Machine Learning baselines on the identical training set
    and evaluates on the identical held-out test set.
    """
    # 1. Logistic Regression
    lr = LogisticRegression(random_state=42, max_iter=1000, C=1.0)
    lr.fit(X_train, y_train)
    lr_prob = lr.predict_proba(X_test)[:, 1]
    lr_pred = (lr_prob >= 0.5).astype(int)
    lr_metrics = evaluate_classifier(y_test, lr_pred, lr_prob)
    
    # 2. Random Forest
    rf = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42)
    rf.fit(X_train, y_train)
    rf_prob = rf.predict_proba(X_test)[:, 1]
    rf_pred = (rf_prob >= 0.5).astype(int)
    rf_metrics = evaluate_classifier(y_test, rf_pred, rf_prob)
    
    return {
        "lr_model": lr, "lr_prob": lr_prob, "lr_pred": lr_pred, "lr_metrics": lr_metrics,
        "rf_model": rf, "rf_prob": rf_prob, "rf_pred": rf_pred, "rf_metrics": rf_metrics
    }

def compute_mlp_permutation_importance(model, X_test, y_test, feature_names):
    """
    Computes permutation importance for the Deep Learning MLP:
    Shuffles each feature column and measures drop in ROC-AUC.
    """
    baseline_prob = model.predict(X_test, verbose=0).ravel()
    baseline_auc = roc_auc_score(y_test, baseline_prob)
    
    importances = []
    np.random.seed(42)
    
    for i in range(X_test.shape[1]):
        X_shuffled = X_test.copy()
        # Shuffle column i
        X_shuffled[:, i] = np.random.permutation(X_shuffled[:, i])
        shuffled_prob = model.predict(X_shuffled, verbose=0).ravel()
        shuffled_auc = roc_auc_score(y_test, shuffled_prob)
        drop = baseline_auc - shuffled_auc
        importances.append(drop)
        
    df_imp = pd.DataFrame({
        "Feature": feature_names,
        "Importance_Drop_AUC": importances
    }).sort_values(by="Importance_Drop_AUC", ascending=False).reset_index(drop=True)
    
    return df_imp

def generate_evaluation_plots(history_df, y_test, mlp_prob, mlp_pred, mlp_cm,
                              baselines, df_imp, feature_names):
    """
    Generates and saves all required model evaluation visualizations.
    """
    print("[INFO] Generating Model Evaluation Visualizations...")
    
    # -------------------------------------------------------------
    # Plot 1: Training & Validation Loss Curve
    # -------------------------------------------------------------
    plt.figure(figsize=(8, 5))
    epochs = range(1, len(history_df) + 1)
    plt.plot(epochs, history_df['loss'], 'b-o', markersize=4, label='Training Loss', linewidth=2)
    plt.plot(epochs, history_df['val_loss'], 'r-s', markersize=4, label='Validation Loss', linewidth=2)
    min_val_loss_epoch = history_df['val_loss'].idxmin() + 1
    min_val_loss = history_df['val_loss'].min()
    plt.axvline(min_val_loss_epoch, color='green', linestyle='--', linewidth=1.5,
                label=f'Optimal Epoch ({min_val_loss_epoch}): {min_val_loss:.3f}')
    plt.title("MLP Training and Validation Loss Across Epochs", fontsize=14, weight='bold', pad=15)
    plt.xlabel("Epochs", fontsize=12)
    plt.ylabel("Binary Cross-Entropy Loss", fontsize=12)
    plt.legend(fontsize=11)
    plt.tight_layout()
    p1 = os.path.join(RESULTS_DIR, "eval_training_validation_loss.png")
    plt.savefig(p1, dpi=300)
    plt.close()
    print(f"  [+] Saved: {p1}")

    # -------------------------------------------------------------
    # Plot 2: Training & Validation Accuracy Curve
    # -------------------------------------------------------------
    plt.figure(figsize=(8, 5))
    plt.plot(epochs, [a * 100 for a in history_df['accuracy']], 'b-o', markersize=4, label='Training Accuracy', linewidth=2)
    plt.plot(epochs, [a * 100 for a in history_df['val_accuracy']], 'r-s', markersize=4, label='Validation Accuracy', linewidth=2)
    plt.title("MLP Training and Validation Accuracy Across Epochs", fontsize=14, weight='bold', pad=15)
    plt.xlabel("Epochs", fontsize=12)
    plt.ylabel("Accuracy (%)", fontsize=12)
    plt.legend(fontsize=11)
    plt.tight_layout()
    p2 = os.path.join(RESULTS_DIR, "eval_training_validation_accuracy.png")
    plt.savefig(p2, dpi=300)
    plt.close()
    print(f"  [+] Saved: {p2}")

    # -------------------------------------------------------------
    # Plot 3: Confusion Matrix
    # -------------------------------------------------------------
    plt.figure(figsize=(7, 6))
    sns.heatmap(mlp_cm, annot=True, fmt='d', cmap='Blues', cbar=False,
                xticklabels=["Absence (0)", "Presence (1)"],
                yticklabels=["Absence (0)", "Presence (1)"],
                annot_kws={"size": 14, "weight": "bold"})
    plt.title("Test Set Confusion Matrix - Deep Learning MLP", fontsize=14, weight='bold', pad=15)
    plt.xlabel("Predicted Class", fontsize=12)
    plt.ylabel("True Class", fontsize=12)
    
    # Annotate breakdown
    tn, fp, fn, tp = mlp_cm.ravel()
    summary_text = f"True Negatives: {tn} | False Positives: {fp}\nFalse Negatives: {fn} | True Positives: {tp}"
    plt.figtext(0.5, 0.01, summary_text, wrap=True, horizontalalignment='center', fontsize=10, weight='bold')
    plt.tight_layout(rect=[0, 0.05, 1, 1])
    p3 = os.path.join(RESULTS_DIR, "eval_confusion_matrix.png")
    plt.savefig(p3, dpi=300)
    plt.close()
    print(f"  [+] Saved: {p3}")

    # -------------------------------------------------------------
    # Plot 4: ROC Curves & AUC Comparison
    # -------------------------------------------------------------
    plt.figure(figsize=(8, 6.5))
    
    # MLP
    fpr_mlp, tpr_mlp, _ = roc_curve(y_test, mlp_prob)
    auc_mlp = roc_auc_score(y_test, mlp_prob)
    plt.plot(fpr_mlp, tpr_mlp, color='#d9534f', linewidth=2.5,
             label=f'MLP Neural Network (AUC = {auc_mlp:.3f})')
    
    # Logistic Regression
    fpr_lr, tpr_lr, _ = roc_curve(y_test, baselines['lr_prob'])
    auc_lr = roc_auc_score(y_test, baselines['lr_prob'])
    plt.plot(fpr_lr, tpr_lr, color='#2b5c8f', linewidth=2, linestyle='--',
             label=f'Logistic Regression (AUC = {auc_lr:.3f})')
    
    # Random Forest
    fpr_rf, tpr_rf, _ = roc_curve(y_test, baselines['rf_prob'])
    auc_rf = roc_auc_score(y_test, baselines['rf_prob'])
    plt.plot(fpr_rf, tpr_rf, color='#27ae60', linewidth=2, linestyle='-.',
             label=f'Random Forest (AUC = {auc_rf:.3f})')
    
    plt.plot([0, 1], [0, 1], color='gray', linestyle=':', label='Random Chance (AUC = 0.500)')
    plt.title("Receiver Operating Characteristic (ROC) Comparison", fontsize=14, weight='bold', pad=15)
    plt.xlabel("False Positive Rate (1 - Specificity)", fontsize=12)
    plt.ylabel("True Positive Rate (Sensitivity / Recall)", fontsize=12)
    plt.legend(loc='lower right', fontsize=11)
    plt.tight_layout()
    p4 = os.path.join(RESULTS_DIR, "eval_roc_curve.png")
    plt.savefig(p4, dpi=300)
    plt.close()
    print(f"  [+] Saved: {p4}")

    # -------------------------------------------------------------
    # Plot 5: Precision-Recall Curve
    # -------------------------------------------------------------
    plt.figure(figsize=(8, 6))
    prec, rec, _ = precision_recall_curve(y_test, mlp_prob)
    ap = average_precision_score(y_test, mlp_prob)
    plt.plot(rec, prec, color='#8e44ad', linewidth=2.5, label=f'MLP Precision-Recall (AP = {ap:.3f})')
    plt.title("Precision-Recall Curve - Test Set Evaluation", fontsize=14, weight='bold', pad=15)
    plt.xlabel("Recall (Sensitivity)", fontsize=12)
    plt.ylabel("Precision (Positive Predictive Value)", fontsize=12)
    plt.legend(loc='lower left', fontsize=11)
    plt.tight_layout()
    p5 = os.path.join(RESULTS_DIR, "eval_precision_recall_curve.png")
    plt.savefig(p5, dpi=300)
    plt.close()
    print(f"  [+] Saved: {p5}")

    # -------------------------------------------------------------
    # Plot 6: Permutation Feature Importance Bar Chart
    # -------------------------------------------------------------
    plt.figure(figsize=(10, 6))
    top_imp = df_imp.head(10).iloc[::-1]  # Top 10 reversed for horizontal plot
    colors = sns.color_palette("viridis", len(top_imp))
    plt.barh(top_imp['Feature'], top_imp['Importance_Drop_AUC'], color=colors, edgecolor='black')
    plt.title("Top-10 Feature Importance (Permutation Drop in Test AUC)", fontsize=14, weight='bold', pad=15)
    plt.xlabel("Drop in ROC-AUC When Feature Values Are Shuffled", fontsize=12)
    plt.ylabel("Clinical Feature", fontsize=12)
    plt.tight_layout()
    p6 = os.path.join(RESULTS_DIR, "eval_feature_importance.png")
    plt.savefig(p6, dpi=300)
    plt.close()
    print(f"  [+] Saved: {p6}")

    # -------------------------------------------------------------
    # Plot 7: Model Comparison Grouped Bar Chart
    # -------------------------------------------------------------
    plt.figure(figsize=(9, 5.5))
    metrics_names = ["Accuracy", "Precision", "Recall", "F1-Score", "ROC-AUC"]
    
    mlp_m = evaluate_classifier(y_test, mlp_pred, mlp_prob)
    lr_m = baselines['lr_metrics']
    rf_m = baselines['rf_metrics']
    
    mlp_vals = [mlp_m["Accuracy"], mlp_m["Precision"], mlp_m["Recall (Sensitivity)"], mlp_m["F1-Score"], mlp_m["ROC-AUC"]]
    lr_vals = [lr_m["Accuracy"], lr_m["Precision"], lr_m["Recall (Sensitivity)"], lr_m["F1-Score"], lr_m["ROC-AUC"]]
    rf_vals = [rf_m["Accuracy"], rf_m["Precision"], rf_m["Recall (Sensitivity)"], rf_m["F1-Score"], rf_m["ROC-AUC"]]
    
    x = np.arange(len(metrics_names))
    width = 0.25
    
    plt.bar(x - width, mlp_vals, width, label='MLP (Keras)', color='#d9534f', edgecolor='black')
    plt.bar(x, lr_vals, width, label='Logistic Regression', color='#2b5c8f', edgecolor='black')
    plt.bar(x + width, rf_vals, width, label='Random Forest', color='#27ae60', edgecolor='black')
    
    plt.title("Benchmarking Evaluation Metrics Across Architectures", fontsize=14, weight='bold', pad=15)
    plt.ylabel("Score (0.0 to 1.0)", fontsize=12)
    plt.xticks(x, metrics_names, fontsize=11)
    plt.ylim(0.0, 1.05)
    plt.legend(loc='lower right', fontsize=10)
    plt.tight_layout()
    p7 = os.path.join(RESULTS_DIR, "eval_model_comparison.png")
    plt.savefig(p7, dpi=300)
    plt.close()
    print(f"  [+] Saved: {p7}")

    print("[SUCCESS] All 7 Model Evaluation visualizations generated and saved.")

if __name__ == "__main__":
    df = load_dataset()
    df_feat = engineer_clinical_features(df)
    prep = split_and_preprocess(df_feat, deduplicate=True)
    
    X_train, y_train = prep["X_train"], prep["y_train"]
    X_test, y_test = prep["X_test"], prep["y_test"]
    feature_names = prep["feature_cols"]
    
    # 1. Load trained MLP
    mlp_model = load_trained_mlp()
    mlp_prob = mlp_model.predict(X_test, verbose=0).ravel()
    mlp_pred = (mlp_prob >= 0.5).astype(int)
    mlp_metrics = evaluate_classifier(y_test, mlp_pred, mlp_prob)
    
    print("\n--- DEEP LEARNING MLP TEST SET METRICS ---")
    for k, v in mlp_metrics.items():
        if k != "Confusion_Matrix":
            print(f"  {k}: {v}")
    print("\nConfusion Matrix:\n", mlp_metrics["Confusion_Matrix"])
    
    # 2. Train baseline models
    baselines = train_baselines(X_train, y_train, X_test, y_test)
    
    # 3. Model Comparison Table
    comparison_data = [
        {"Model": "MLP (Neural Network)", **{k: v for k, v in mlp_metrics.items() if k != "Confusion_Matrix"}},
        {"Model": "Logistic Regression", **{k: v for k, v in baselines['lr_metrics'].items() if k != "Confusion_Matrix"}},
        {"Model": "Random Forest", **{k: v for k, v in baselines['rf_metrics'].items() if k != "Confusion_Matrix"}}
    ]
    df_comp = pd.DataFrame(comparison_data)
    df_comp.to_csv(os.path.join(RESULTS_DIR, "model_comparison_results.csv"), index=False)
    print("\n--- MODEL COMPARISON TABLE (HELD-OUT TEST SET) ---")
    print(df_comp.to_string(index=False))
    
    # 4. Feature Importance
    df_imp = compute_mlp_permutation_importance(mlp_model, X_test, y_test, feature_names)
    df_imp.to_csv(os.path.join(RESULTS_DIR, "feature_importance_results.csv"), index=False)
    print("\n--- TOP-10 PERMUTATION FEATURE IMPORTANCE ---")
    print(df_imp.head(10).to_string(index=False))
    
    # 5. Generate plots
    history_df = pd.read_csv(os.path.join(RESULTS_DIR, "training_history.csv"))
    generate_evaluation_plots(history_df, y_test, mlp_prob, mlp_pred, mlp_metrics["Confusion_Matrix"],
                              baselines, df_imp, feature_names)
