"""
CardioInsight AI - Deep Learning Model Training & Hyperparameter Tuning Module
Author: Senior Data Scientist / ML Engineer
Description: Builds, compiles, trains, tunes, and serializes the Multilayer Perceptron (MLP)
             for heart disease binary classification using TensorFlow/Keras.
             Performs structured hyperparameter validation experiments and saves the optimal model.
"""

import os
import random
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras import layers, models, regularizers, callbacks

from data_preprocessing import load_dataset, engineer_clinical_features, split_and_preprocess

# Set deterministic random seeds
SEED = 42
os.environ['PYTHONHASHSEED'] = str(SEED)
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

MODELS_DIR = "models"
RESULTS_DIR = "results"
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

def build_mlp_model(input_dim, hidden_units=(64, 32, 16), dropout_rate=0.2, learning_rate=0.001, l2_reg=0.001):
    """
    Constructs a Deep Multilayer Perceptron (MLP) architecture:
    - Input Layer (input_dim)
    - Dense Layer 1 (hidden_units[0] neurons, ReLU, L2 regularized)
    - Batch Normalization
    - Dropout (dropout_rate)
    - Dense Layer 2 (hidden_units[1] neurons, ReLU, L2 regularized)
    - Dropout (dropout_rate / 2)
    - Dense Layer 3 (hidden_units[2] neurons, ReLU)
    - Output Layer (1 neuron, Sigmoid activation)
    """
    model = models.Sequential(name="CardioInsight_MLP")
    model.add(layers.Input(shape=(input_dim,)))
    
    # Layer 1
    model.add(layers.Dense(
        hidden_units[0], 
        activation='relu', 
        kernel_initializer='he_normal',
        kernel_regularizer=regularizers.l2(l2_reg),
        name="dense_hidden_1"
    ))
    model.add(layers.BatchNormalization(name="batch_norm_1"))
    model.add(layers.Dropout(dropout_rate, name="dropout_1"))
    
    # Layer 2
    model.add(layers.Dense(
        hidden_units[1], 
        activation='relu', 
        kernel_initializer='he_normal',
        kernel_regularizer=regularizers.l2(l2_reg),
        name="dense_hidden_2"
    ))
    model.add(layers.Dropout(dropout_rate / 2, name="dropout_2"))
    
    # Layer 3
    if len(hidden_units) > 2:
        model.add(layers.Dense(
            hidden_units[2], 
            activation='relu', 
            kernel_initializer='he_normal',
            name="dense_hidden_3"
        ))
        
    # Output Layer for binary classification
    model.add(layers.Dense(1, activation='sigmoid', name="output_classification"))
    
    optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
    model.compile(
        optimizer=optimizer,
        loss='binary_crossentropy',
        metrics=[
            'accuracy',
            tf.keras.metrics.AUC(name='auc'),
            tf.keras.metrics.Precision(name='precision'),
            tf.keras.metrics.Recall(name='recall')
        ]
    )
    return model

def run_hyperparameter_tuning(X_train, y_train, X_val, y_val, input_dim):
    """
    Systematically conducts hyperparameter search across reasonable architectural
    and optimization configurations using the validation set (strict test set isolation).
    """
    print("\n[INFO] Starting Systematic Hyperparameter Experiments on Validation Set...")
    configs = [
        {"name": "Exp 1: Baseline MLP", "units": (64, 32, 16), "lr": 0.001, "drop": 0.2, "batch": 16},
        {"name": "Exp 2: Wider Capacity", "units": (128, 64, 32), "lr": 0.001, "drop": 0.3, "batch": 16},
        {"name": "Exp 3: Reduced LR", "units": (64, 32, 16), "lr": 0.0003, "drop": 0.2, "batch": 16},
        {"name": "Exp 4: Larger Batch", "units": (64, 32, 16), "lr": 0.001, "drop": 0.2, "batch": 32},
        {"name": "Exp 5: Light Regularization", "units": (64, 32, 16), "lr": 0.001, "drop": 0.1, "batch": 16},
    ]
    
    results = []
    
    for cfg in configs:
        model = build_mlp_model(
            input_dim=input_dim,
            hidden_units=cfg["units"],
            dropout_rate=cfg["drop"],
            learning_rate=cfg["lr"]
        )
        early_stop = callbacks.EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
        
        history = model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=40,
            batch_size=cfg["batch"],
            verbose=0,
            callbacks=[early_stop]
        )
        
        val_eval = model.evaluate(X_val, y_val, verbose=0)
        # val_eval returns [loss, accuracy, auc, precision, recall]
        val_loss, val_acc, val_auc, val_prec, val_rec = val_eval
        
        results.append({
            "Experiment": cfg["name"],
            "Architecture": f"{cfg['units']}",
            "Learning Rate": cfg["lr"],
            "Dropout": cfg["drop"],
            "Batch Size": cfg["batch"],
            "Val Loss": round(float(val_loss), 4),
            "Val Accuracy (%)": round(float(val_acc) * 100, 2),
            "Val AUC": round(float(val_auc), 4),
            "Val Precision (%)": round(float(val_prec) * 100, 2),
            "Val Recall (%)": round(float(val_rec) * 100, 2)
        })
        print(f"  Completed {cfg['name']}: Val Acc = {val_acc*100:.2f}%, Val Loss = {val_loss:.4f}, Val AUC = {val_auc:.4f}")
        
    df_tuning = pd.DataFrame(results)
    tuning_csv_path = os.path.join(RESULTS_DIR, "hyperparameter_tuning_results.csv")
    df_tuning.to_csv(tuning_csv_path, index=False)
    print(f"[INFO] Hyperparameter tuning complete. Results saved to {tuning_csv_path}")
    return df_tuning

def train_best_model(X_train, y_train, X_val, y_val, input_dim, best_cfg):
    """
    Trains the optimal MLP configuration with early stopping and learning rate scheduling.
    """
    print(f"\n[INFO] Training Best Model Configuration ({best_cfg['Experiment']}) for up to 50 Epochs...")
    
    model = build_mlp_model(
        input_dim=input_dim,
        hidden_units=eval(best_cfg["Architecture"]),
        dropout_rate=float(best_cfg["Dropout"]),
        learning_rate=float(best_cfg["Learning Rate"])
    )
    
    cb_early_stop = callbacks.EarlyStopping(
        monitor='val_loss',
        patience=12,
        restore_best_weights=True,
        verbose=1
    )
    cb_reduce_lr = callbacks.ReduceLROnPlateau(
        monitor='val_loss',
        factor=0.5,
        patience=5,
        min_lr=1e-5,
        verbose=1
    )
    
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=50,
        batch_size=int(best_cfg["Batch Size"]),
        callbacks=[cb_early_stop, cb_reduce_lr],
        verbose=1
    )
    
    # Save training history
    history_df = pd.DataFrame(history.history)
    history_path = os.path.join(RESULTS_DIR, "training_history.csv")
    history_df.to_csv(history_path, index=False)
    print(f"[INFO] Training history saved to {history_path}")
    
    # Save model artifact
    model_save_path = os.path.join(MODELS_DIR, "best_heart_disease_mlp.keras")
    model.save(model_save_path)
    print(f"[SUCCESS] Trained model saved to {model_save_path}")
    
    return model, history_df

if __name__ == "__main__":
    df = load_dataset()
    df_feat = engineer_clinical_features(df)
    prep = split_and_preprocess(df_feat, deduplicate=True)
    
    X_train, y_train = prep["X_train"], prep["y_train"]
    X_val, y_val = prep["X_val"], prep["y_val"]
    input_dim = X_train.shape[1]
    
    # 1. Hyperparameter tuning experiments
    df_tuning = run_hyperparameter_tuning(X_train, y_train, X_val, y_val, input_dim)
    print("\n--- HYPERPARAMETER EXPERIMENT SUMMARY TABLE ---")
    print(df_tuning.to_string(index=False))
    
    # 2. Select best configuration by Validation AUC / Accuracy
    best_idx = df_tuning['Val AUC'].idxmax()
    best_cfg = df_tuning.iloc[best_idx]
    print(f"\n[INFO] Best Selected Configuration: {best_cfg['Experiment']} (Val AUC: {best_cfg['Val AUC']})")
    
    # 3. Train final model
    best_model, hist = train_best_model(X_train, y_train, X_val, y_val, input_dim, best_cfg)
